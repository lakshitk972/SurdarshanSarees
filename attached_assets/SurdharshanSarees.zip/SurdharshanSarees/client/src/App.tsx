import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import { Suspense, lazy } from "react";
import { AuthProvider } from "@/hooks/use-auth";
import { CartProvider } from "@/hooks/use-cart";
import { ProtectedRoute, AdminRoute } from "@/lib/protected-route";
import HomePage from "@/pages/home-page";
import AuthPage from "@/pages/auth-page";
import NavBar from "@/components/NavBar";
import Footer from "@/components/Footer";
import CartSidebar from "@/components/CartSidebar";
import { Loader2 } from "lucide-react";

// Lazy loaded pages
const CollectionsPage = lazy(() => import("@/pages/collections-page"));
const ProductPage = lazy(() => import("@/pages/product-page"));
const CustomOrdersPage = lazy(() => import("@/pages/custom-orders-page"));
const AboutPage = lazy(() => import("@/pages/about-page"));
const ContactPage = lazy(() => import("@/pages/contact-page"));
const CheckoutPage = lazy(() => import("@/pages/checkout-page"));

// Admin pages
const AdminDashboard = lazy(() => import("@/pages/admin/dashboard"));
const AdminProducts = lazy(() => import("@/pages/admin/products"));
const AdminAddProduct = lazy(() => import("@/pages/admin/add-product"));
const AdminOrders = lazy(() => import("@/pages/admin/orders"));
const AdminCustomRequests = lazy(() => import("@/pages/admin/custom-requests"));

// Loading component
const Loading = () => (
  <div className="flex items-center justify-center min-h-screen">
    <Loader2 className="h-8 w-8 animate-spin text-primary" />
  </div>
);

function Router() {
  return (
    <Suspense fallback={<Loading />}>
      <Switch>
        <Route path="/" component={HomePage} />
        <Route path="/auth" component={AuthPage} />
        <Route path="/collections" component={CollectionsPage} />
        <Route path="/collections/:category" component={CollectionsPage} />
        <Route path="/product/:slug" component={ProductPage} />
        <Route path="/custom-orders" component={CustomOrdersPage} />
        <Route path="/about" component={AboutPage} />
        <Route path="/contact" component={ContactPage} />
        <ProtectedRoute path="/checkout" component={CheckoutPage} />
        
        {/* Admin routes */}
        <AdminRoute path="/admin" component={AdminDashboard} />
        <AdminRoute path="/admin/products" component={AdminProducts} />
        <AdminRoute path="/admin/products/add" component={AdminAddProduct} />
        <AdminRoute path="/admin/products/edit/:id" component={AdminAddProduct} />
        <AdminRoute path="/admin/orders" component={AdminOrders} />
        <AdminRoute path="/admin/custom-requests" component={AdminCustomRequests} />
        
        {/* Fallback to 404 */}
        <Route component={NotFound} />
      </Switch>
    </Suspense>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <CartProvider>
          <div className="flex flex-col min-h-screen">
            <NavBar />
            <div className="flex-1">
              <Router />
            </div>
            <Footer />
            <CartSidebar />
          </div>
          <Toaster />
        </CartProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
