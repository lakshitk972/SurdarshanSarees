import { useCart } from "@/hooks/use-cart";
import { CartItem } from "@/components/ui/cart-item";
import { Button } from "@/components/ui/button";
import { formatPrice } from "@/lib/utils";
import { Link } from "wouter";
import { X, ArrowRight } from "lucide-react";

export default function CartSidebar() {
  const { 
    items, 
    isCartOpen, 
    closeCart, 
    itemCount, 
    subtotal 
  } = useCart();
  
  return (
    <div 
      className={`fixed right-0 top-0 h-full w-full md:w-96 bg-white shadow-xl z-50 transform transition-transform duration-300 ease-in-out ${
        isCartOpen ? 'translate-x-0' : 'translate-x-full'
      }`}
    >
      <div className="p-6 h-full flex flex-col">
        <div className="flex justify-between items-center mb-6">
          <h2 className="font-playfair text-2xl font-semibold text-charcoal">Your Cart</h2>
          <button 
            onClick={closeCart}
            className="text-charcoal hover:text-primary transition-colors duration-300"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
        
        <div className="flex-grow overflow-y-auto">
          {itemCount === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center">
              <div className="mb-4">
                <div className="w-16 h-16 mx-auto bg-muted rounded-full flex items-center justify-center">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M6 2L3 6V20C3 20.5304 3.21071 21.0391 3.58579 21.4142C3.96086 21.7893 4.46957 22 5 22H19C19.5304 22 20.0391 21.7893 20.4142 21.4142C20.7893 21.0391 21 20.5304 21 20V6L18 2H6Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M3 6H21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M16 10C16 11.0609 15.5786 12.0783 14.8284 12.8284C14.0783 13.5786 13.0609 14 12 14C10.9391 14 9.92172 13.5786 9.17157 12.8284C8.42143 12.0783 8 11.0609 8 10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </div>
              </div>
              <h3 className="text-lg font-medium mb-2">Your cart is empty</h3>
              <p className="text-muted-foreground mb-6">Looks like you haven't added anything to your cart yet.</p>
              <Button 
                onClick={closeCart}
                className="bg-primary hover:bg-primary/90"
              >
                Continue Shopping
              </Button>
            </div>
          ) : (
            <div className="space-y-4 mb-6">
              {items.map((item) => (
                <CartItem 
                  key={item.product.id} 
                  product={item.product} 
                  quantity={item.quantity} 
                />
              ))}
            </div>
          )}
        </div>
        
        {itemCount > 0 && (
          <div className="border-t border-gray-200 pt-4">
            <div className="flex justify-between mb-2 text-sm">
              <span className="text-gray-600">Subtotal</span>
              <span className="font-medium">{formatPrice(subtotal)}</span>
            </div>
            <div className="flex justify-between mb-2 text-sm">
              <span className="text-gray-600">Shipping</span>
              <span className="font-medium">Free</span>
            </div>
            <div className="flex justify-between text-lg font-semibold mt-2">
              <span>Total</span>
              <span className="text-primary">{formatPrice(subtotal)}</span>
            </div>
            
            <div className="mt-6">
              <Link href="/checkout">
                <Button 
                  className="w-full py-6 bg-primary hover:bg-primary/90 text-white font-medium rounded-md transition-colors duration-300 flex items-center justify-center"
                  onClick={closeCart}
                >
                  <span>Proceed to Checkout</span>
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
              <Button 
                variant="outline"
                className="w-full py-6 mt-2 border border-primary text-primary font-medium rounded-md hover:bg-background transition-colors duration-300"
                onClick={closeCart}
              >
                Continue Shopping
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
