import { useQuery } from "@tanstack/react-query";
import { Category } from "@shared/schema";
import { Link } from "wouter";
import { ArrowRight } from "lucide-react";

export default function FeaturedCategories() {
  const { data: categories } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });
  
  // If categories are not available yet, show a loading state
  if (!categories) {
    return (
      <section className="py-16 px-6 md:px-12 lg:px-24 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="font-playfair text-3xl md:text-4xl font-bold text-charcoal mb-4">
              Curated Collections
            </h2>
            <p className="font-poppins text-gray-600 max-w-2xl mx-auto">
              Discover our handpicked selections featuring the finest craftsmanship and traditional techniques.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3].map((i) => (
              <div key={i} className="rounded-lg overflow-hidden shadow-lg relative h-80 bg-gray-200 animate-pulse" />
            ))}
          </div>
        </div>
      </section>
    );
  }
  
  return (
    <section className="py-16 px-6 md:px-12 lg:px-24 bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="font-playfair text-3xl md:text-4xl font-bold text-charcoal mb-4">
            Curated Collections
          </h2>
          <p className="font-poppins text-gray-600 max-w-2xl mx-auto">
            Discover our handpicked selections featuring the finest craftsmanship and traditional techniques.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {categories.slice(0, 3).map((category) => (
            <div key={category.id} className="feature-card rounded-lg overflow-hidden shadow-lg relative group">
              <div className="overflow-hidden">
                <img 
                  src={category.imageUrl || "https://images.unsplash.com/photo-1610030181087-285c5fa57493?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"} 
                  alt={category.name} 
                  className="feature-image w-full h-80 object-cover transition-transform duration-800 group-hover:scale-105"
                />
              </div>
              <div className="absolute inset-0 bg-primary/30 flex flex-col justify-end p-6 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <h3 className="font-playfair text-white text-2xl font-semibold mb-2">{category.name}</h3>
                <p className="font-poppins text-white/90 mb-4">{category.description}</p>
                <Link href={`/collections/${category.slug}`}>
                  <a className="font-poppins text-white inline-flex items-center">
                    Explore Collection <ArrowRight className="ml-2 h-4 w-4" />
                  </a>
                </Link>
              </div>
              <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-black/70 to-transparent group-hover:opacity-0 transition-opacity duration-300">
                <h3 className="font-playfair text-white text-2xl font-semibold">{category.name}</h3>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
