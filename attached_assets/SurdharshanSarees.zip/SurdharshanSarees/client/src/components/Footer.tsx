import { Link } from "wouter";
import { 
  Instagram, 
  Facebook, 
  Twitter, 
  Linkedin,
  MapPin,
  Phone,
  Mail
} from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-charcoal text-white pt-16 pb-8 px-6 md:px-12 lg:px-24">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <div>
            <h3 className="font-playfair text-2xl font-bold mb-6">Surdharshan Designer</h3>
            <p className="font-poppins text-gray-300 mb-6">
              Crafting elegance through traditional artistry and contemporary designs since 2000.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-300 hover:text-secondary transition-colors duration-300">
                <Instagram size={20} />
              </a>
              <a href="#" className="text-gray-300 hover:text-secondary transition-colors duration-300">
                <Facebook size={20} />
              </a>
              <a href="#" className="text-gray-300 hover:text-secondary transition-colors duration-300">
                <Linkedin size={20} />
              </a>
              <a href="#" className="text-gray-300 hover:text-secondary transition-colors duration-300">
                <Twitter size={20} />
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="font-playfair font-semibold text-lg mb-6">Collections</h4>
            <ul className="space-y-3 font-poppins">
              <li>
                <Link href="/collections/bridal-collection">
                  <a className="text-gray-300 hover:text-secondary transition-colors duration-300">
                    Bridal Collection
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/collections/designer-sarees">
                  <a className="text-gray-300 hover:text-secondary transition-colors duration-300">
                    Designer Sarees
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/collections/luxury-lehengas">
                  <a className="text-gray-300 hover:text-secondary transition-colors duration-300">
                    Luxury Lehengas
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/collections/festive-wear">
                  <a className="text-gray-300 hover:text-secondary transition-colors duration-300">
                    Festive Wear
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/collections">
                  <a className="text-gray-300 hover:text-secondary transition-colors duration-300">
                    New Arrivals
                  </a>
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-playfair font-semibold text-lg mb-6">Customer Service</h4>
            <ul className="space-y-3 font-poppins">
              <li>
                <Link href="/shipping-policy">
                  <a className="text-gray-300 hover:text-secondary transition-colors duration-300">
                    Shipping Policy
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/returns-policy">
                  <a className="text-gray-300 hover:text-secondary transition-colors duration-300">
                    Returns & Exchanges
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/size-guide">
                  <a className="text-gray-300 hover:text-secondary transition-colors duration-300">
                    Size Guide
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/care-instructions">
                  <a className="text-gray-300 hover:text-secondary transition-colors duration-300">
                    Care Instructions
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/faq">
                  <a className="text-gray-300 hover:text-secondary transition-colors duration-300">
                    FAQs
                  </a>
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-playfair font-semibold text-lg mb-6">Contact Us</h4>
            <ul className="space-y-3 font-poppins">
              <li className="flex items-start">
                <MapPin className="mt-1 mr-3 text-secondary flex-shrink-0" size={18} />
                <span className="text-gray-300">
                  123 Fashion Street, Luxury Lane<br />New Delhi, 110001, India
                </span>
              </li>
              <li className="flex items-start">
                <Phone className="mt-1 mr-3 text-secondary flex-shrink-0" size={18} />
                <span className="text-gray-300">+91 98765 43210</span>
              </li>
              <li className="flex items-start">
                <Mail className="mt-1 mr-3 text-secondary flex-shrink-0" size={18} />
                <span className="text-gray-300">lakshitkumawat16@gmail.com</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-700 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="font-poppins text-gray-400 text-sm mb-4 md:mb-0">
              © {new Date().getFullYear()} Surdharshan Designer. All rights reserved.
            </p>
            <div className="flex flex-wrap justify-center gap-4 text-sm font-poppins">
              <Link href="/privacy-policy">
                <a className="text-gray-400 hover:text-secondary transition-colors duration-300">
                  Privacy Policy
                </a>
              </Link>
              <Link href="/terms-of-service">
                <a className="text-gray-400 hover:text-secondary transition-colors duration-300">
                  Terms of Service
                </a>
              </Link>
              <Link href="/sitemap">
                <a className="text-gray-400 hover:text-secondary transition-colors duration-300">
                  Sitemap
                </a>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
