import { Link } from "wouter";
import { ChevronDown } from "lucide-react";

export default function Hero() {
  return (
    <section className="hero-section min-h-screen flex flex-col justify-center relative">
      <div className="absolute inset-0 flex flex-col justify-center px-6 md:px-12 lg:px-24 z-10 animate-fadeIn">
        <div className="max-w-2xl">
          <h1 className="font-playfair text-4xl md:text-6xl font-bold text-white leading-tight mb-6">
            Elegance Woven in Every Thread
          </h1>
          <p className="font-cormorant text-xl md:text-2xl text-white/90 mb-8">
            Discover the timeless beauty of traditional Indian craftsmanship 
            with our exquisite collection of sarees and lehengas.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Link href="/collections">
              <a className="bg-primary hover:bg-primary/90 text-white py-3 px-8 rounded-md font-poppins font-medium transition-colors duration-300 text-center">
                Explore Collection
              </a>
            </Link>
            <Link href="/custom-orders">
              <a className="bg-transparent border-2 border-white text-white py-3 px-8 rounded-md font-poppins font-medium hover:bg-white/20 transition-colors duration-300 text-center">
                Custom Orders
              </a>
            </Link>
          </div>
        </div>
      </div>
      <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 z-10 text-white text-center">
        <p className="font-poppins mb-2">Scroll to discover</p>
        <div className="animate-bounce">
          <ChevronDown className="h-6 w-6" />
        </div>
      </div>
    </section>
  );
}
