import { Link, useLocation } from "wouter";
import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useCart } from "@/hooks/use-cart";
import { Search, User, ShoppingBag, Menu, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useMobile } from "@/hooks/use-mobile";

export default function NavBar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { user, logoutMutation } = useAuth();
  const { toggleCart, itemCount } = useCart();
  const [location] = useLocation();
  const isMobile = useMobile();
  
  // Close mobile menu when route changes
  useEffect(() => {
    setIsMenuOpen(false);
  }, [location]);
  
  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  return (
    <nav className="bg-white shadow-md sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20">
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <Link href="/">
                <h1 className="font-playfair text-primary text-2xl md:text-3xl font-bold cursor-pointer">Surdharshan Designer</h1>
              </Link>
            </div>
          </div>
          <div className="hidden md:flex items-center space-x-8">
            <Link href="/">
              <a className={`font-poppins text-charcoal hover:text-primary animated-underline ${location === '/' ? 'font-medium' : ''}`}>Home</a>
            </Link>
            <Link href="/collections">
              <a className={`font-poppins text-charcoal hover:text-primary animated-underline ${location.startsWith('/collections') ? 'font-medium' : ''}`}>Collections</a>
            </Link>
            <Link href="/about">
              <a className={`font-poppins text-charcoal hover:text-primary animated-underline ${location === '/about' ? 'font-medium' : ''}`}>About</a>
            </Link>
            <Link href="/custom-orders">
              <a className={`font-poppins text-charcoal hover:text-primary animated-underline ${location === '/custom-orders' ? 'font-medium' : ''}`}>Custom Orders</a>
            </Link>
            <Link href="/contact">
              <a className={`font-poppins text-charcoal hover:text-primary animated-underline ${location === '/contact' ? 'font-medium' : ''}`}>Contact</a>
            </Link>
          </div>
          <div className="flex items-center space-x-4">
            <Link href="/collections">
              <a className="font-poppins text-charcoal hover:text-primary p-2">
                <Search className="h-5 w-5" />
              </a>
            </Link>
            
            {/* User dropdown or login link */}
            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="font-poppins text-charcoal hover:text-primary p-2">
                    <User className="h-5 w-5" />
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel>My Account</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  {user.isAdmin && (
                    <>
                      <Link href="/admin">
                        <DropdownMenuItem className="cursor-pointer">Dashboard</DropdownMenuItem>
                      </Link>
                      <Link href="/admin/products">
                        <DropdownMenuItem className="cursor-pointer">Manage Products</DropdownMenuItem>
                      </Link>
                      <Link href="/admin/orders">
                        <DropdownMenuItem className="cursor-pointer">Manage Orders</DropdownMenuItem>
                      </Link>
                      <Link href="/admin/custom-requests">
                        <DropdownMenuItem className="cursor-pointer">Custom Requests</DropdownMenuItem>
                      </Link>
                      <DropdownMenuSeparator />
                    </>
                  )}
                  <DropdownMenuItem onClick={handleLogout} className="cursor-pointer text-red-500">
                    <LogOut className="mr-2 h-4 w-4" />
                    Logout
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Link href="/auth">
                <a className="font-poppins text-charcoal hover:text-primary p-2">
                  <User className="h-5 w-5" />
                </a>
              </Link>
            )}
            
            {/* Cart button */}
            <button 
              className="font-poppins text-charcoal hover:text-primary p-2 relative"
              onClick={toggleCart}
            >
              <ShoppingBag className="h-5 w-5" />
              {itemCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-primary text-white rounded-full w-5 h-5 flex items-center justify-center text-xs">
                  {itemCount}
                </span>
              )}
            </button>
            
            {/* Mobile menu button */}
            <button 
              className="md:hidden font-poppins text-charcoal hover:text-primary p-2"
              onClick={toggleMenu}
            >
              <Menu className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile menu */}
      {isMobile && (
        <div className={`md:hidden ${isMenuOpen ? 'block' : 'hidden'}`}>
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-white">
            <Link href="/">
              <a className="block px-3 py-2 font-poppins text-charcoal hover:bg-background hover:text-primary rounded-md">Home</a>
            </Link>
            <Link href="/collections">
              <a className="block px-3 py-2 font-poppins text-charcoal hover:bg-background hover:text-primary rounded-md">Collections</a>
            </Link>
            <Link href="/about">
              <a className="block px-3 py-2 font-poppins text-charcoal hover:bg-background hover:text-primary rounded-md">About</a>
            </Link>
            <Link href="/custom-orders">
              <a className="block px-3 py-2 font-poppins text-charcoal hover:bg-background hover:text-primary rounded-md">Custom Orders</a>
            </Link>
            <Link href="/contact">
              <a className="block px-3 py-2 font-poppins text-charcoal hover:bg-background hover:text-primary rounded-md">Contact</a>
            </Link>
            
            {user?.isAdmin && (
              <>
                <div className="mt-4 mb-2 px-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                  Admin
                </div>
                <Link href="/admin">
                  <a className="block px-3 py-2 font-poppins text-charcoal hover:bg-background hover:text-primary rounded-md">Dashboard</a>
                </Link>
                <Link href="/admin/products">
                  <a className="block px-3 py-2 font-poppins text-charcoal hover:bg-background hover:text-primary rounded-md">Manage Products</a>
                </Link>
                <Link href="/admin/orders">
                  <a className="block px-3 py-2 font-poppins text-charcoal hover:bg-background hover:text-primary rounded-md">Manage Orders</a>
                </Link>
                <Link href="/admin/custom-requests">
                  <a className="block px-3 py-2 font-poppins text-charcoal hover:bg-background hover:text-primary rounded-md">Custom Requests</a>
                </Link>
              </>
            )}
            
            {user && (
              <Button 
                variant="destructive" 
                className="w-full mt-4"
                onClick={handleLogout}
                disabled={logoutMutation.isPending}
              >
                {logoutMutation.isPending ? "Logging out..." : "Logout"}
              </Button>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}
