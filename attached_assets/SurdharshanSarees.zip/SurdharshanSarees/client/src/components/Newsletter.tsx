import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";

export default function Newsletter() {
  const [email, setEmail] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email || !email.includes('@')) {
      toast({
        title: "Invalid email",
        description: "Please enter a valid email address",
        variant: "destructive",
      });
      return;
    }
    
    setIsSubmitting(true);
    
    // Simulate form submission
    setTimeout(() => {
      setIsSubmitting(false);
      setEmail("");
      toast({
        title: "Subscription successful",
        description: "Thank you for subscribing to our newsletter!",
      });
    }, 1000);
  };
  
  return (
    <section className="py-16 px-6 md:px-12 lg:px-24 bg-primary">
      <div className="max-w-7xl mx-auto text-center">
        <h2 className="font-playfair text-3xl md:text-4xl font-bold text-white mb-4">
          Join Our Newsletter
        </h2>
        <p className="font-poppins text-white/90 max-w-2xl mx-auto mb-8">
          Subscribe to our newsletter to receive exclusive updates on new collections, 
          special offers, and styling tips.
        </p>
        
        <form 
          className="max-w-xl mx-auto flex flex-col sm:flex-row gap-4"
          onSubmit={handleSubmit}
        >
          <Input
            type="email"
            placeholder="Enter your email address"
            className="flex-grow px-4 py-3 rounded-md font-poppins focus:outline-none bg-white"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <Button 
            type="submit" 
            className="bg-secondary hover:bg-secondary/90 text-white font-poppins font-medium px-6 py-3 rounded-md transition-colors duration-300 whitespace-nowrap"
            disabled={isSubmitting}
          >
            {isSubmitting ? "Subscribing..." : "Subscribe Now"}
          </Button>
        </form>
      </div>
    </section>
  );
}
