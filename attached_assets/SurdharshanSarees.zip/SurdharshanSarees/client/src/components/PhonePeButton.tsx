import React, { useState } from 'react';
import { apiRequest } from '@/lib/queryClient';
import { Button } from '@/components/ui/button';
import { Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface PhonePeButtonProps {
  amount: number;
  customerData: {
    name: string;
    email: string;
    phone: string;
  };
  onSuccess?: (data: any) => void;
  onFailure?: (error: string) => void;
}

const PhonePeButton: React.FC<PhonePeButtonProps> = ({
  amount,
  customerData,
  onSuccess,
  onFailure
}) => {
  const [isLoading, setIsLoading] = useState(false);
  const [merchantTransactionId, setMerchantTransactionId] = useState<string | null>(null);
  const { toast } = useToast();

  const handlePayment = async () => {
    try {
      setIsLoading(true);
      
      // Create PhonePe payment
      const response = await apiRequest('POST', '/api/phonepe/create-order', {
        amount: amount.toString(),
        customerName: customerData.name,
        customerEmail: customerData.email,
        customerPhone: customerData.phone
      });
      
      const paymentData = await response.json();
      
      if (paymentData.success) {
        // Save the merchant transaction ID for later verification
        setMerchantTransactionId(paymentData.merchantTransactionId);
        
        // Redirect to PhonePe payment page
        if (paymentData.data && paymentData.data.data && paymentData.data.data.instrumentResponse) {
          const redirectUrl = paymentData.data.data.instrumentResponse.redirectInfo.url;
          window.location.href = redirectUrl;
        } else {
          throw new Error('Invalid payment response');
        }
      } else {
        throw new Error(paymentData.message || 'Payment initiation failed');
      }
    } catch (error) {
      setIsLoading(false);
      const errorMessage = error instanceof Error ? error.message : 'Payment failed';
      
      toast({
        title: 'Payment Error',
        description: errorMessage,
        variant: 'destructive'
      });
      
      if (onFailure) {
        onFailure(errorMessage);
      }
    }
  };

  return (
    <Button
      onClick={handlePayment}
      disabled={isLoading}
      className="w-full bg-blue-600 hover:bg-blue-700 py-6 flex items-center justify-center"
    >
      {isLoading ? (
        <>
          <Loader2 className="mr-2 h-5 w-5 animate-spin" />
          Processing...
        </>
      ) : (
        <>Pay with PhonePe</>
      )}
    </Button>
  );
};

export default PhonePeButton;
