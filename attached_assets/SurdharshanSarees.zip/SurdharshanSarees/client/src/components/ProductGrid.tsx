import { useQuery } from "@tanstack/react-query";
import { Product } from "@shared/schema";
import { ProductCard } from "@/components/ui/product-card";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import { Link } from "wouter";

interface ProductGridProps {
  title: string;
  description?: string;
  queryKey: string;
  limit?: number;
  viewAllLink?: string;
}

export default function ProductGrid({ 
  title, 
  description, 
  queryKey, 
  limit = 8,
  viewAllLink = "/collections" 
}: ProductGridProps) {
  const { data, isLoading } = useQuery<Product[]>({
    queryKey: [queryKey],
  });
  
  const products = data ? (limit ? data.slice(0, limit) : data) : [];
  
  return (
    <section className="py-16 px-6 md:px-12 lg:px-24 bg-background">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="font-playfair text-3xl md:text-4xl font-bold text-charcoal mb-4">
            {title}
          </h2>
          {description && (
            <p className="font-poppins text-gray-600 max-w-2xl mx-auto">
              {description}
            </p>
          )}
        </div>
        
        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-12">
            {Array.from({ length: limit }).map((_, index) => (
              <div key={index} className="bg-white rounded-lg overflow-hidden shadow-md h-[400px] animate-pulse">
                <div className="w-full h-72 bg-gray-200"></div>
                <div className="p-4 space-y-2">
                  <div className="h-5 bg-gray-200 rounded"></div>
                  <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  <div className="flex justify-between items-center">
                    <div className="h-4 bg-gray-200 rounded w-1/4"></div>
                    <div className="h-4 bg-gray-200 rounded w-1/3"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-12 animate-slideUp">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}
        
        {viewAllLink && (
          <div className="text-center">
            <Link href={viewAllLink}>
              <Button className="inline-flex items-center justify-center py-3 px-8 bg-primary hover:bg-primary/90 text-white font-poppins font-medium rounded-md transition-colors duration-300">
                <span>View All Products</span>
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        )}
      </div>
    </section>
  );
}
