import { useEffect, useState } from 'react';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { apiRequest } from '@/lib/queryClient';
import { Loader2 } from 'lucide-react';

interface RazorpayButtonProps {
  amount: number;
  onSuccess: (paymentId: string) => void;
  onFailure: (error: string) => void;
  customerData: {
    name: string;
    email: string;
    contact: string;
  };
}

declare global {
  interface Window {
    Razorpay: any;
  }
}

export default function RazorpayButton({
  amount,
  onSuccess,
  onFailure,
  customerData,
}: RazorpayButtonProps) {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  // Function to load Razorpay script
  const loadRazorpayScript = () => {
    return new Promise((resolve) => {
      const script = document.createElement('script');
      script.src = 'https://checkout.razorpay.com/v1/checkout.js';
      script.onload = () => {
        resolve(true);
      };
      script.onerror = () => {
        resolve(false);
      };
      document.body.appendChild(script);
    });
  };

  // Function to create and display the Razorpay payment form
  const displayRazorpay = async () => {
    setLoading(true);
    
    try {
      // 1. Check if Razorpay script is loaded
      const isLoaded = await loadRazorpayScript();
      if (!isLoaded) {
        throw new Error('Razorpay SDK failed to load');
      }
      
      // 2. Create order on the server
      const orderResponse = await apiRequest('POST', '/api/razorpay/create-order', {
        amount: amount.toString(),
        currency: 'INR',
      });
      
      const orderData = await orderResponse.json();
      
      // 3. Configure Razorpay options
      const options = {
        key: orderData.key,
        amount: orderData.amount.toString(),
        currency: orderData.currency,
        name: 'Surdharshan Designer',
        description: 'Premium Sarees & Lehengas',
        order_id: orderData.id,
        handler: async (response: any) => {
          try {
            // 4. Verify payment on server
            const verifyResponse = await apiRequest('POST', '/api/razorpay/verify-payment', {
              razorpay_order_id: response.razorpay_order_id,
              razorpay_payment_id: response.razorpay_payment_id,
              razorpay_signature: response.razorpay_signature,
            });
            
            const verifyData = await verifyResponse.json();
            
            if (verifyData.verified) {
              toast({
                title: "Payment Successful",
                description: "Your payment has been processed successfully",
              });
              onSuccess(response.razorpay_payment_id);
            } else {
              throw new Error('Payment verification failed');
            }
          } catch (error) {
            console.error('Payment verification error:', error);
            onFailure('Payment verification failed');
          }
        },
        prefill: {
          name: customerData.name,
          email: customerData.email,
          contact: customerData.contact,
        },
        notes: {
          address: 'Surdharshan Designer, India',
        },
        theme: {
          color: '#795744', // Match your brand color
        },
        modal: {
          ondismiss: function() {
            onFailure('Payment cancelled by user');
          },
        }
      };
      
      // 5. Create new instance of Razorpay and open checkout form
      const paymentObject = new window.Razorpay(options);
      paymentObject.open();
      
    } catch (error) {
      console.error('Razorpay error:', error);
      onFailure(error instanceof Error ? error.message : 'Payment processing failed');
      toast({
        title: "Payment Error",
        description: error instanceof Error ? error.message : 'Payment processing failed',
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Button 
      onClick={displayRazorpay} 
      disabled={loading}
      className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
    >
      {loading ? (
        <>
          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          Processing...
        </>
      ) : (
        'Pay with Razorpay (India)'
      )}
    </Button>
  );
}
