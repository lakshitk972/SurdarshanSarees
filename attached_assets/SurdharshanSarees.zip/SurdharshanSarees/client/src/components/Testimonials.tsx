import { Star, StarHalf } from "lucide-react";

const testimonials = [
  {
    id: 1,
    name: "Priya Sharma",
    location: "Delhi",
    image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&auto=format&fit=crop&w=120&q=80",
    rating: 5,
    testimonial: "My wedding lehenga from Surdharshan Designer was absolutely breathtaking. The attention to detail in the embroidery and the quality of the fabric exceeded all my expectations. I received countless compliments on my big day."
  },
  {
    id: 2,
    name: "Anita Reddy",
    location: "Bangalore",
    image: "https://images.unsplash.com/photo-1607346256330-dee7af15f7c5?ixlib=rb-4.0.3&auto=format&fit=crop&w=120&q=80",
    rating: 4.5,
    testimonial: "I ordered a custom saree for my daughter's wedding and the team at Surdharshan Designer made the process so seamless. They carefully listened to all my requirements and delivered a stunning piece that perfectly matched our vision."
  },
  {
    id: 3,
    name: "Kavita Malhotra",
    location: "Mumbai",
    image: "https://images.unsplash.com/photo-1566492031773-4f4e44671857?ixlib=rb-4.0.3&auto=format&fit=crop&w=120&q=80",
    rating: 5,
    testimonial: "The luxury collection at Surdharshan Designer is unparalleled. I've purchased several sarees from them over the years, and each one is a masterpiece. Their craftsmanship and dedication to preserving traditional techniques while incorporating modern designs is truly commendable."
  }
];

export default function Testimonials() {
  const renderRating = (rating: number) => {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    
    return (
      <div className="flex mb-4">
        {Array(fullStars).fill(0).map((_, i) => (
          <Star key={i} className="text-secondary" size={18} fill="currentColor" />
        ))}
        {hasHalfStar && <StarHalf className="text-secondary" size={18} fill="currentColor" />}
      </div>
    );
  };
  
  return (
    <section className="py-16 px-6 md:px-12 lg:px-24 bg-background">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="font-playfair text-3xl md:text-4xl font-bold text-charcoal mb-4">
            Customer Stories
          </h2>
          <p className="font-poppins text-gray-600 max-w-2xl mx-auto">
            Hear from our valued customers who have experienced the luxury and craftsmanship of Surdharshan Designer.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial) => (
            <div key={testimonial.id} className="bg-white p-8 rounded-lg shadow-md">
              <div className="flex items-center mb-6">
                <div className="w-14 h-14 rounded-full overflow-hidden mr-4">
                  <img 
                    src={testimonial.image} 
                    alt={testimonial.name} 
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <h3 className="font-poppins font-medium text-lg text-charcoal">
                    {testimonial.name}
                  </h3>
                  <p className="text-sm text-gray-600">{testimonial.location}</p>
                </div>
              </div>
              
              {renderRating(testimonial.rating)}
              
              <p className="font-poppins text-gray-600 italic">
                "{testimonial.testimonial}"
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
