import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { 
  LayoutDashboard, 
  ShoppingBag, 
  ClipboardList, 
  MessageSquareText, 
  LogOut, 
  ChevronLeft,
  Settings
} from "lucide-react";
import { Button } from "@/components/ui/button";

interface AdminLayoutProps {
  children: React.ReactNode;
  title: string;
}

export default function AdminLayout({ children, title }: AdminLayoutProps) {
  const { logoutMutation } = useAuth();
  const [location] = useLocation();
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  const navItems = [
    { label: "Dashboard", icon: <LayoutDashboard size={18} />, path: "/admin" },
    { label: "Products", icon: <ShoppingBag size={18} />, path: "/admin/products" },
    { label: "Orders", icon: <ClipboardList size={18} />, path: "/admin/orders" },
    { label: "Custom Requests", icon: <MessageSquareText size={18} />, path: "/admin/custom-requests" },
    { label: "Settings", icon: <Settings size={18} />, path: "/admin/settings" },
  ];
  
  return (
    <div className="min-h-screen bg-background flex">
      {/* Sidebar */}
      <aside className="w-64 bg-sidebar fixed h-full z-10 hidden md:block">
        <div className="flex flex-col h-full">
          <div className="p-4 border-b border-sidebar-border">
            <Link href="/">
              <a className="flex items-center space-x-2">
                <span className="font-playfair text-xl font-bold text-sidebar-primary">Admin Panel</span>
              </a>
            </Link>
          </div>
          
          <nav className="flex-1 p-4">
            <ul className="space-y-2">
              {navItems.map((item) => (
                <li key={item.path}>
                  <Link href={item.path}>
                    <a className={`flex items-center space-x-3 px-4 py-2.5 rounded-md transition-colors ${
                      location === item.path
                        ? "bg-sidebar-accent text-sidebar-accent-foreground"
                        : "text-sidebar-foreground hover:bg-sidebar-accent/10"
                    }`}>
                      {item.icon}
                      <span>{item.label}</span>
                    </a>
                  </Link>
                </li>
              ))}
            </ul>
          </nav>
          
          <div className="p-4 border-t border-sidebar-border">
            <Button
              variant="ghost"
              className="w-full justify-start text-sidebar-foreground hover:bg-sidebar-accent/10 hover:text-sidebar-foreground"
              onClick={handleLogout}
            >
              <LogOut size={18} className="mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </aside>
      
      {/* Main content */}
      <div className="flex-1 md:ml-64">
        <header className="bg-white border-b border-border sticky top-0 z-30">
          <div className="px-4 py-3 md:py-4 flex items-center justify-between">
            <div className="flex items-center">
              <Link href="/">
                <a className="mr-4 text-gray-500 hover:text-primary md:hidden">
                  <ChevronLeft size={24} />
                </a>
              </Link>
              <h1 className="text-xl md:text-2xl font-playfair font-bold">{title}</h1>
            </div>
            <Link href="/">
              <a className="text-sm text-primary hover:underline">View Store</a>
            </Link>
          </div>
        </header>
        
        <main className="p-4 md:p-8">
          {children}
        </main>
      </div>
    </div>
  );
}
