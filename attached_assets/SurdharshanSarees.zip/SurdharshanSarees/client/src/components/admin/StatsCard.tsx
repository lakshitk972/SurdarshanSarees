import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface StatsCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  change?: {
    value: string | number;
    positive: boolean;
  };
  className?: string;
}

export default function StatsCard({
  title,
  value,
  icon,
  change,
  className,
}: StatsCardProps) {
  return (
    <Card className={cn("overflow-hidden", className)}>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-muted-foreground">{title}</p>
            <h3 className="text-2xl font-bold mt-2 mb-1">{value}</h3>
            {change && (
              <p className={cn(
                "text-xs font-medium flex items-center",
                change.positive ? "text-emerald" : "text-destructive"
              )}>
                {change.positive ? '↑' : '↓'} {change.value}
                <span className="text-muted-foreground ml-1">vs. last month</span>
              </p>
            )}
          </div>
          <div className="rounded-full p-2.5 bg-primary/10 text-primary">
            {icon}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
