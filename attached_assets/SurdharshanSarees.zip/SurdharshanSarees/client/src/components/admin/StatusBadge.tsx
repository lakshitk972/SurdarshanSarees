import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface StatusBadgeProps {
  status: string;
  className?: string;
}

export default function StatusBadge({ status, className }: StatusBadgeProps) {
  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'completed':
      case 'delivered':
      case 'paid':
      case 'approved':
        return 'bg-emerald text-white hover:bg-emerald';
      case 'pending':
      case 'processing':
        return 'bg-secondary text-secondary-foreground hover:bg-secondary/90';
      case 'cancelled':
      case 'rejected':
        return 'bg-destructive text-destructive-foreground hover:bg-destructive/90';
      default:
        return 'bg-primary/20 text-primary hover:bg-primary/30';
    }
  };

  return (
    <Badge
      className={cn(
        'font-normal capitalize px-2 py-0.5',
        getStatusColor(status),
        className
      )}
    >
      {status}
    </Badge>
  );
}
