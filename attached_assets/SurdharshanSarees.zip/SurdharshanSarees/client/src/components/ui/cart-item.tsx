import { Product } from "@shared/schema";
import { formatPrice } from "@/lib/utils";
import { useCart } from "@/hooks/use-cart";
import { Minus, Plus, Trash2 } from "lucide-react";

interface CartItemProps {
  product: Product;
  quantity: number;
}

export function CartItem({ product, quantity }: CartItemProps) {
  const { updateQuantity, removeItem } = useCart();
  
  const increaseQuantity = () => {
    updateQuantity(product.id, quantity + 1);
  };
  
  const decreaseQuantity = () => {
    if (quantity > 1) {
      updateQuantity(product.id, quantity - 1);
    }
  };
  
  const handleRemove = () => {
    removeItem(product.id);
  };
  
  return (
    <div className="cart-item flex p-3 rounded-lg transition-colors duration-300 hover:bg-secondary/10">
      <div className="w-20 h-24 rounded-md overflow-hidden">
        <img src={product.imageUrl} alt={product.name} className="w-full h-full object-cover" />
      </div>
      <div className="ml-4 flex-grow">
        <h3 className="font-poppins font-medium text-charcoal">{product.name}</h3>
        <p className="text-sm text-gray-600 truncate">{product.description}</p>
        <div className="flex justify-between items-center mt-2">
          <p className="font-medium text-primary">{formatPrice(product.price)}</p>
          <div className="flex items-center">
            <button 
              onClick={decreaseQuantity}
              className="w-6 h-6 rounded-full bg-background flex items-center justify-center"
            >
              <Minus className="w-3 h-3 text-charcoal" />
            </button>
            <span className="mx-2 text-sm">{quantity}</span>
            <button 
              onClick={increaseQuantity}
              className="w-6 h-6 rounded-full bg-background flex items-center justify-center"
            >
              <Plus className="w-3 h-3 text-charcoal" />
            </button>
          </div>
        </div>
      </div>
      <button 
        onClick={handleRemove}
        className="self-start ml-2 text-gray-400 hover:text-primary transition-colors duration-300"
      >
        <Trash2 className="w-4 h-4" />
      </button>
    </div>
  );
}
