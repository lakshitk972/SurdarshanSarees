import { Product } from "@shared/schema";
import { Link } from "wouter";
import { formatPrice } from "@/lib/utils";
import { RatingDisplay } from "@/components/ui/rating-display";
import { useCart } from "@/hooks/use-cart";
import { Eye, ShoppingBag } from "lucide-react";

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const { addItem } = useCart();
  
  const addToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addItem(product, 1);
  };
  
  return (
    <div className="product-card bg-white rounded-lg overflow-hidden shadow-md transition-all duration-300 hover:transform hover:-translate-y-2 hover:shadow-xl">
      <div className="relative group">
        <img 
          src={product.imageUrl} 
          alt={product.name} 
          className="w-full h-72 object-cover"
        />
        <div className="absolute inset-0 bg-black bg-opacity-20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
          <Link href={`/product/${product.slug}`}>
            <button className="bg-white p-2 rounded-full mr-2 hover:bg-primary hover:text-white transition-colors duration-300">
              <Eye size={18} />
            </button>
          </Link>
          <button 
            onClick={addToCart}
            className="bg-white p-2 rounded-full hover:bg-primary hover:text-white transition-colors duration-300"
          >
            <ShoppingBag size={18} />
          </button>
        </div>
        
        {/* Product tags */}
        <div className="absolute top-3 right-3 flex flex-col gap-2">
          {product.featured && (
            <span className="bg-secondary text-white text-xs px-2 py-1 rounded">Luxury</span>
          )}
          {product.isNew && (
            <span className="bg-emerald text-white text-xs px-2 py-1 rounded">New Arrival</span>
          )}
        </div>
      </div>
      
      <Link href={`/product/${product.slug}`}>
        <div className="p-4">
          <h3 className="font-poppins font-medium text-lg text-charcoal mb-1">{product.name}</h3>
          <p className="text-sm text-gray-600 mb-2 truncate">{product.description}</p>
          <div className="flex justify-between items-center">
            <p className="font-medium text-primary">{formatPrice(product.price)}</p>
            <RatingDisplay rating={parseFloat(product.rating?.toString() || "0")} numReviews={product.numReviews || 0} />
          </div>
        </div>
      </Link>
    </div>
  );
}
