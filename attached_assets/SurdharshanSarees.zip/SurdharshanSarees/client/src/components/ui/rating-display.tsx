import { getStarCounts } from '@/lib/utils';

interface RatingDisplayProps {
  rating: number;
  numReviews?: number;
}

export function RatingDisplay({ rating, numReviews }: RatingDisplayProps) {
  const { fullStars, hasHalfStar, emptyStars } = getStarCounts(rating);
  
  return (
    <div className="flex items-center">
      {[...Array(fullStars)].map((_, i) => (
        <i key={`full-${i}`} className="fas fa-star text-gold-light text-sm"></i>
      ))}
      {hasHalfStar && <i className="fas fa-star-half-alt text-gold-light text-sm"></i>}
      {[...Array(emptyStars)].map((_, i) => (
        <i key={`empty-${i}`} className="far fa-star text-gold-light text-sm"></i>
      ))}
      {numReviews !== undefined && <span className="text-xs text-gray-600 ml-1">({numReviews})</span>}
    </div>
  );
}
