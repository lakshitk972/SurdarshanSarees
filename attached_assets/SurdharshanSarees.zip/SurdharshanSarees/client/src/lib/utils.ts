import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Format price to Indian Rupee format
export function formatPrice(price: number | string): string {
  const numPrice = typeof price === 'string' ? parseFloat(price) : price;
  
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0
  }).format(numPrice);
}

// Create a slug from a string
export function slugify(text: string): string {
  return text
    .toString()
    .toLowerCase()
    .replace(/\s+/g, '-')
    .replace(/[^\w-]+/g, '')
    .replace(/--+/g, '-')
    .replace(/^-+/, '')
    .replace(/-+$/, '');
}

// Generate star count arrays for ratings
export function getStarCounts(rating: number) {
  const fullStars = Math.floor(rating);
  const hasHalfStar = rating % 1 >= 0.5;
  const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
  
  return { fullStars, hasHalfStar, emptyStars };
}

// Get price range text from min and max
export function getPriceRangeText(min?: number, max?: number): string {
  if (min === undefined && max === undefined) {
    return "All Prices";
  }
  
  if (min !== undefined && max !== undefined) {
    return `₹${min.toLocaleString()} - ₹${max.toLocaleString()}`;
  }
  
  if (min !== undefined) {
    return `Above ₹${min.toLocaleString()}`;
  }
  
  return `Below ₹${max!.toLocaleString()}`;
}

// Truncate text with ellipsis
export function truncateText(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text;
  return text.slice(0, maxLength) + '...';
}
