import { Link } from "wouter";
import { Check } from "lucide-react";
import Newsletter from "@/components/Newsletter";

export default function AboutPage() {
  return (
    <>
      <section className="py-16 px-6 md:px-12 lg:px-24 bg-background">
        <div className="max-w-5xl mx-auto text-center">
          <h1 className="font-playfair text-4xl md:text-5xl font-bold text-charcoal mb-6">
            Our Heritage of Excellence
          </h1>
          <p className="font-poppins text-xl text-gray-600 max-w-3xl mx-auto">
            Discover the story behind Surdharshan Designer, a symbol of luxury and elegance in the Indian fashion landscape.
          </p>
        </div>
      </section>
      
      <section className="py-16 px-6 md:px-12 lg:px-24 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <img 
                src="https://images.unsplash.com/photo-1610030181087-285c5fa57493?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80" 
                alt="Craftsmanship" 
                className="rounded-lg shadow-lg"
              />
            </div>
            
            <div>
              <h2 className="font-playfair text-3xl font-bold text-charcoal mb-6">
                Our Journey
              </h2>
              <p className="font-poppins text-gray-600 mb-6">
                Surdharshan Designer was founded in 2000 with a vision to create exceptional Indian ethnic wear that 
                celebrates the rich cultural heritage of India. What began as a small boutique has now grown into a 
                renowned brand that caters to discerning customers who appreciate fine craftsmanship and timeless elegance.
              </p>
              <p className="font-poppins text-gray-600 mb-6">
                Our founder, Lakshit Kumawat, was inspired by the intricate artistry of traditional Indian textiles and 
                techniques. He embarked on a journey to revive and preserve these age-old crafts while infusing them with 
                contemporary aesthetics to create pieces that resonate with the modern Indian woman.
              </p>
              <p className="font-poppins text-gray-600">
                Today, Surdharshan Designer stands as a testament to the successful fusion of tradition and modernity, 
                offering exquisite sarees, lehengas, and custom-made ensembles that are cherished by our customers.
              </p>
            </div>
          </div>
        </div>
      </section>
      
      <section className="py-16 px-6 md:px-12 lg:px-24 bg-background">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="font-playfair text-3xl md:text-4xl font-bold text-charcoal mb-4">
              Our Values
            </h2>
            <p className="font-poppins text-gray-600 max-w-2xl mx-auto">
              The principles that guide everything we do at Surdharshan Designer.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-lg shadow-md">
              <div className="bg-primary/10 w-14 h-14 rounded-full flex items-center justify-center mb-6">
                <Check className="text-primary h-6 w-6" />
              </div>
              <h3 className="font-playfair text-xl font-bold text-charcoal mb-3">
                Artisanal Excellence
              </h3>
              <p className="font-poppins text-gray-600">
                We are committed to maintaining the highest standards of craftsmanship in every piece we create. 
                Our skilled artisans bring decades of experience and passion to their work.
              </p>
            </div>
            
            <div className="bg-white p-8 rounded-lg shadow-md">
              <div className="bg-primary/10 w-14 h-14 rounded-full flex items-center justify-center mb-6">
                <Check className="text-primary h-6 w-6" />
              </div>
              <h3 className="font-playfair text-xl font-bold text-charcoal mb-3">
                Ethical Practices
              </h3>
              <p className="font-poppins text-gray-600">
                We believe in fair trade and ethical business practices. We source our materials responsibly and 
                ensure that our artisans receive fair wages and work in good conditions.
              </p>
            </div>
            
            <div className="bg-white p-8 rounded-lg shadow-md">
              <div className="bg-primary/10 w-14 h-14 rounded-full flex items-center justify-center mb-6">
                <Check className="text-primary h-6 w-6" />
              </div>
              <h3 className="font-playfair text-xl font-bold text-charcoal mb-3">
                Cultural Preservation
              </h3>
              <p className="font-poppins text-gray-600">
                We are dedicated to preserving and promoting traditional Indian textile arts and techniques. 
                Through our work, we hope to keep these cultural treasures alive for future generations.
              </p>
            </div>
          </div>
        </div>
      </section>
      
      <section className="py-16 px-6 md:px-12 lg:px-24 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="order-2 lg:order-1">
              <h2 className="font-playfair text-3xl font-bold text-charcoal mb-6">
                Our Artisans
              </h2>
              <p className="font-poppins text-gray-600 mb-6">
                The heart and soul of Surdharshan Designer are our skilled artisans who have mastered traditional 
                techniques passed down through generations. These master craftspeople bring our designs to life with 
                their exceptional skills in embroidery, weaving, and embellishment.
              </p>
              <p className="font-poppins text-gray-600 mb-6">
                Many of our artisans specialize in specific techniques such as Gotta Patti, Jardoji, and Zari work, 
                each requiring years of training and practice to perfect. We take pride in providing a platform for 
                these artisans to showcase their talent and preserve their craft.
              </p>
              <p className="font-poppins text-gray-600 mb-6">
                Through our collaboration with these skilled individuals, we not only create beautiful garments but 
                also contribute to sustaining traditional art forms that might otherwise be lost in today's 
                fast-fashion world.
              </p>
              
              <Link href="/collections">
                <a className="inline-flex items-center justify-center py-3 px-8 bg-primary hover:bg-primary/90 text-white font-poppins font-medium rounded-md transition-colors duration-300">
                  Explore Our Collections
                </a>
              </Link>
            </div>
            
            <div className="order-1 lg:order-2">
              <div className="grid grid-cols-2 gap-4">
                <img 
                  src="https://images.unsplash.com/photo-1624398090966-c3d5a2174c84?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" 
                  alt="Artisan at work" 
                  className="rounded-lg"
                />
                <img 
                  src="https://images.unsplash.com/photo-1578148377458-25d11132ecaa?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" 
                  alt="Detailed embroidery" 
                  className="rounded-lg"
                />
              </div>
            </div>
          </div>
        </div>
      </section>
      
      <section className="py-16 px-6 md:px-12 lg:px-24 bg-background">
        <div className="max-w-7xl mx-auto text-center">
          <h2 className="font-playfair text-3xl md:text-4xl font-bold text-charcoal mb-6">
            Our Promise
          </h2>
          <p className="font-poppins text-xl text-gray-600 max-w-3xl mx-auto mb-10">
            When you choose Surdharshan Designer, you're not just buying a garment; you're investing in a piece of 
            art that carries the legacy of Indian craftsmanship and the promise of exceptional quality.
          </p>
          
          <div className="flex flex-col md:flex-row gap-8 justify-center">
            <Link href="/collections">
              <a className="py-3 px-8 bg-primary hover:bg-primary/90 text-white font-poppins font-medium rounded-md transition-colors duration-300">
                Explore Collections
              </a>
            </Link>
            <Link href="/custom-orders">
              <a className="py-3 px-8 bg-white hover:bg-gray-50 text-primary border border-primary font-poppins font-medium rounded-md transition-colors duration-300">
                Custom Orders
              </a>
            </Link>
          </div>
        </div>
      </section>
      
      <Newsletter />
    </>
  );
}
