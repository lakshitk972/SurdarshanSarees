import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import AdminLayout from "@/components/admin/AdminLayout";
import StatusBadge from "@/components/admin/StatusBadge";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Pagination } from "@/components/ui/pagination";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import {
  Loader2,
  Search,
  Filter,
  Eye,
  XCircle,
  MessageSquare,
} from "lucide-react";

// Custom Request type
interface CustomRequest {
  id: number;
  userId: number | null;
  fullName: string;
  email: string;
  phone: string;
  productType: string;
  materials: string;
  workTypes: string;
  budgetRange: string;
  requirements: string | null;
  status: string;
  referenceImages: string | null;
  adminNotes: string | null;
  createdAt: string;
  updatedAt: string;
  user?: {
    id: number;
    username: string;
    email: string;
  };
}

export default function CustomRequestsPage() {
  const { toast } = useToast();
  
  // State for filters and pagination
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedRequest, setSelectedRequest] = useState<CustomRequest | null>(null);
  const [statusToUpdate, setStatusToUpdate] = useState<string>("");
  const [adminNotes, setAdminNotes] = useState<string>("");
  
  // Get custom requests with filters
  const {
    data: requestData,
    isLoading,
    isError,
  } = useQuery<{ requests: CustomRequest[]; count: number }>({
    queryKey: [
      "/api/admin/custom-requests",
      {
        page: currentPage,
        limit: 10,
        status: statusFilter || undefined,
      },
    ],
  });
  
  // Update custom request status mutation
  const updateStatusMutation = useMutation({
    mutationFn: async ({
      id,
      status,
      adminNotes,
    }: {
      id: number;
      status: string;
      adminNotes: string;
    }) => {
      await apiRequest("PUT", `/api/admin/custom-requests/${id}`, {
        status,
        adminNotes,
      });
    },
    onSuccess: () => {
      toast({
        title: "Request Updated",
        description: `Request status has been updated to ${statusToUpdate}`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/custom-requests"] });
      setSelectedRequest(null);
      setStatusToUpdate("");
      setAdminNotes("");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update request: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  const handleStatusChange = (value: string) => {
    setStatusFilter(value);
    setCurrentPage(1);
  };
  
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearch(e.target.value);
    setCurrentPage(1);
  };
  
  const handleUpdateStatus = () => {
    if (selectedRequest && statusToUpdate) {
      updateStatusMutation.mutate({
        id: selectedRequest.id,
        status: statusToUpdate,
        adminNotes,
      });
    }
  };
  
  const resetFilters = () => {
    setSearch("");
    setStatusFilter("");
    setCurrentPage(1);
  };
  
  const handleRequestSelect = (request: CustomRequest) => {
    setSelectedRequest(request);
    setStatusToUpdate(request.status);
    setAdminNotes(request.adminNotes || "");
  };
  
  // Calculate total pages
  const totalPages = requestData ? Math.ceil(requestData.count / 10) : 1;
  
  // Request statuses for dropdown
  const requestStatuses = [
    { value: "pending", label: "Pending" },
    { value: "processing", label: "Processing" },
    { value: "approved", label: "Approved" },
    { value: "rejected", label: "Rejected" },
    { value: "completed", label: "Completed" },
  ];
  
  return (
    <AdminLayout title="Custom Design Requests">
      <div className="mb-6 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div className="flex items-center space-x-2">
          {(search || statusFilter) && (
            <Button variant="outline" onClick={resetFilters}>
              Clear Filters
            </Button>
          )}
        </div>
        
        <div className="flex flex-col md:flex-row gap-2">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search requests..."
              className="pl-8 w-full md:w-[250px]"
              value={search}
              onChange={handleSearchChange}
            />
          </div>
          
          <Button
            variant="outline"
            size="icon"
            className="md:hidden"
            onClick={() => 
              document.getElementById("request-filters-container")?.classList.toggle("hidden")
            }
          >
            <Filter className="h-4 w-4" />
          </Button>
        </div>
      </div>
      
      <div id="request-filters-container" className="hidden md:flex flex-wrap gap-2 mb-6">
        <Select value={statusFilter} onValueChange={handleStatusChange}>
          <SelectTrigger className="w-full md:w-[180px]">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="">All Statuses</SelectItem>
            {requestStatuses.map((status) => (
              <SelectItem key={status.value} value={status.value}>
                {status.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      
      {isLoading ? (
        <div className="flex items-center justify-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : isError ? (
        <div className="flex flex-col items-center justify-center h-64">
          <XCircle className="h-10 w-10 text-destructive mb-2" />
          <p className="text-lg font-medium">Failed to load requests</p>
          <Button 
            variant="outline" 
            className="mt-4"
            onClick={() => queryClient.invalidateQueries({ queryKey: ["/api/admin/custom-requests"] })}
          >
            Try Again
          </Button>
        </div>
      ) : requestData?.requests.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-64 text-center">
          <div className="mb-4 text-muted-foreground">
            <MessageSquare className="h-12 w-12 mx-auto mb-2 opacity-20" />
            <h3 className="text-lg font-medium">No custom requests found</h3>
          </div>
          <p className="text-sm text-muted-foreground mb-4">
            {statusFilter
              ? "Try adjusting your filters"
              : "No custom design requests have been submitted yet"}
          </p>
        </div>
      ) : (
        <>
          <div className="rounded-md border overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Request ID</TableHead>
                  <TableHead>Customer</TableHead>
                  <TableHead className="hidden md:table-cell">Product Type</TableHead>
                  <TableHead className="hidden md:table-cell">Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {requestData.requests.map((request) => (
                  <TableRow key={request.id}>
                    <TableCell className="font-medium">#{request.id}</TableCell>
                    <TableCell>{request.fullName}</TableCell>
                    <TableCell className="hidden md:table-cell capitalize">
                      {request.productType.replace('_', ' ')}
                    </TableCell>
                    <TableCell className="hidden md:table-cell">
                      {new Date(request.createdAt).toLocaleDateString()}
                    </TableCell>
                    <TableCell>
                      <StatusBadge status={request.status} />
                    </TableCell>
                    <TableCell className="text-right">
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={() => handleRequestSelect(request)}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                        </DialogTrigger>
                        {selectedRequest && (
                          <DialogContent className="max-w-3xl">
                            <DialogHeader>
                              <DialogTitle>Custom Request #{selectedRequest.id}</DialogTitle>
                              <DialogDescription>
                                Submitted on {new Date(selectedRequest.createdAt).toLocaleDateString()}
                              </DialogDescription>
                            </DialogHeader>
                            
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                              <div>
                                <h3 className="font-medium text-sm mb-2">Customer Information</h3>
                                <div className="bg-muted p-3 rounded-md">
                                  <p><span className="font-medium">Name:</span> {selectedRequest.fullName}</p>
                                  <p><span className="font-medium">Email:</span> {selectedRequest.email}</p>
                                  <p><span className="font-medium">Phone:</span> {selectedRequest.phone}</p>
                                </div>
                              </div>
                              
                              <div>
                                <h3 className="font-medium text-sm mb-2">Request Details</h3>
                                <div className="bg-muted p-3 rounded-md">
                                  <p>
                                    <span className="font-medium">Product Type:</span>{" "}
                                    <span className="capitalize">
                                      {selectedRequest.productType.replace('_', ' ')}
                                    </span>
                                  </p>
                                  <p><span className="font-medium">Budget Range:</span> {selectedRequest.budgetRange.replace('-', ' - ₹')}</p>
                                  <p><span className="font-medium">Status:</span> <StatusBadge status={selectedRequest.status} /></p>
                                </div>
                              </div>
                            </div>
                            
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                              <div>
                                <h3 className="font-medium text-sm mb-2">Materials</h3>
                                <div className="bg-muted p-3 rounded-md">
                                  <div className="flex flex-wrap gap-1">
                                    {selectedRequest.materials.split(', ').map((material, index) => (
                                      <span 
                                        key={index}
                                        className="bg-primary/10 text-primary px-2 py-0.5 rounded text-xs capitalize"
                                      >
                                        {material.replace('_', ' ')}
                                      </span>
                                    ))}
                                  </div>
                                </div>
                              </div>
                              
                              <div>
                                <h3 className="font-medium text-sm mb-2">Work Types</h3>
                                <div className="bg-muted p-3 rounded-md">
                                  <div className="flex flex-wrap gap-1">
                                    {selectedRequest.workTypes.split(', ').map((workType, index) => (
                                      <span 
                                        key={index}
                                        className="bg-secondary/10 text-secondary px-2 py-0.5 rounded text-xs capitalize"
                                      >
                                        {workType.replace('_', ' ')}
                                      </span>
                                    ))}
                                  </div>
                                </div>
                              </div>
                            </div>
                            
                            <div className="mt-4">
                              <h3 className="font-medium text-sm mb-2">Requirements</h3>
                              <div className="bg-muted p-3 rounded-md">
                                <p>{selectedRequest.requirements || "No specific requirements provided."}</p>
                              </div>
                            </div>
                            
                            {selectedRequest.referenceImages && (
                              <div className="mt-4">
                                <h3 className="font-medium text-sm mb-2">Reference Images</h3>
                                <div className="bg-muted p-3 rounded-md">
                                  <p>{selectedRequest.referenceImages}</p>
                                </div>
                              </div>
                            )}
                            
                            <div className="mt-6">
                              <h3 className="font-medium text-sm mb-2">Admin Notes</h3>
                              <Textarea
                                value={adminNotes}
                                onChange={(e) => setAdminNotes(e.target.value)}
                                placeholder="Add notes about this request..."
                                className="min-h-24 resize-y"
                              />
                            </div>
                            
                            <DialogFooter className="mt-6">
                              <div className="flex flex-col sm:flex-row gap-4 w-full justify-between">
                                <Select 
                                  value={statusToUpdate} 
                                  onValueChange={setStatusToUpdate}
                                >
                                  <SelectTrigger className="w-full sm:w-[180px]">
                                    <SelectValue placeholder="Update Status" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    {requestStatuses.map((status) => (
                                      <SelectItem key={status.value} value={status.value}>
                                        {status.label}
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                                
                                <div className="flex gap-2">
                                  <DialogClose asChild>
                                    <Button variant="outline">Cancel</Button>
                                  </DialogClose>
                                  <Button
                                    className="bg-primary"
                                    onClick={handleUpdateStatus}
                                    disabled={
                                      !statusToUpdate ||
                                      (statusToUpdate === selectedRequest.status &&
                                        adminNotes === selectedRequest.adminNotes) ||
                                      updateStatusMutation.isPending
                                    }
                                  >
                                    {updateStatusMutation.isPending ? (
                                      <>
                                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                        Updating...
                                      </>
                                    ) : (
                                      "Update Request"
                                    )}
                                  </Button>
                                </div>
                              </div>
                            </DialogFooter>
                          </DialogContent>
                        )}
                      </Dialog>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          
          {totalPages > 1 && (
            <div className="mt-6 flex justify-center">
              <Pagination
                currentPage={currentPage}
                totalPages={totalPages}
                onPageChange={setCurrentPage}
              />
            </div>
          )}
        </>
      )}
    </AdminLayout>
  );
}
