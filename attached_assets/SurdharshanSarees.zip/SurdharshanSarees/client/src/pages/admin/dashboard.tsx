import { useQuery } from "@tanstack/react-query";
import AdminLayout from "@/components/admin/AdminLayout";
import StatsCard from "@/components/admin/StatsCard";
import StatusBadge from "@/components/admin/StatusBadge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { formatPrice } from "@/lib/utils";
import { 
  ShoppingBag, 
  Users, 
  CreditCard, 
  Banknote, 
  ChevronRight,
  Package,
  MessageSquare
} from "lucide-react";
import { Link } from "wouter";
import { 
  Table, 
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

interface DashboardStats {
  totalOrders: number;
  totalRevenue: number;
  totalCustomers: number;
  pendingOrders: number;
  revenueChange: { value: number; positive: boolean };
  ordersChange: { value: number; positive: boolean };
  customersChange: { value: number; positive: boolean };
}

interface RecentOrder {
  id: number;
  customer: string;
  status: string;
  total: number;
  date: string;
}

interface RecentCustomRequest {
  id: number;
  customer: string;
  productType: string;
  status: string;
  date: string;
}

export default function Dashboard() {
  // Fetch dashboard statistics
  const { data: stats, isLoading: statsLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/admin/dashboard/stats"],
  });
  
  // Fetch recent orders
  const { data: recentOrders, isLoading: ordersLoading } = useQuery<RecentOrder[]>({
    queryKey: ["/api/admin/dashboard/recent-orders"],
  });
  
  // Fetch recent custom requests
  const { data: recentRequests, isLoading: requestsLoading } = useQuery<RecentCustomRequest[]>({
    queryKey: ["/api/admin/dashboard/recent-requests"],
  });
  
  return (
    <AdminLayout title="Dashboard">
      <div className="space-y-6">
        {/* Stats cards */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <StatsCard
            title="Total Orders"
            value={statsLoading ? "Loading..." : stats?.totalOrders.toString() || "0"}
            icon={<ShoppingBag className="h-5 w-5" />}
            change={
              !statsLoading && stats?.ordersChange
                ? {
                    value: `${stats.ordersChange.value}%`,
                    positive: stats.ordersChange.positive,
                  }
                : undefined
            }
          />
          
          <StatsCard
            title="Total Revenue"
            value={
              statsLoading
                ? "Loading..."
                : stats?.totalRevenue
                ? formatPrice(stats.totalRevenue)
                : "₹0"
            }
            icon={<Banknote className="h-5 w-5" />}
            change={
              !statsLoading && stats?.revenueChange
                ? {
                    value: `${stats.revenueChange.value}%`,
                    positive: stats.revenueChange.positive,
                  }
                : undefined
            }
          />
          
          <StatsCard
            title="Total Customers"
            value={statsLoading ? "Loading..." : stats?.totalCustomers.toString() || "0"}
            icon={<Users className="h-5 w-5" />}
            change={
              !statsLoading && stats?.customersChange
                ? {
                    value: `${stats.customersChange.value}%`,
                    positive: stats.customersChange.positive,
                  }
                : undefined
            }
          />
          
          <StatsCard
            title="Pending Orders"
            value={statsLoading ? "Loading..." : stats?.pendingOrders.toString() || "0"}
            icon={<Package className="h-5 w-5" />}
          />
        </div>
        
        {/* Recent orders */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-lg font-medium">Recent Orders</CardTitle>
            <Link href="/admin/orders" className="text-sm text-primary hover:underline flex items-center">
              View all <ChevronRight className="ml-1 h-4 w-4" />
            </Link>
          </CardHeader>
          <CardContent>
            {ordersLoading ? (
              <div className="h-52 flex items-center justify-center">
                <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
              </div>
            ) : recentOrders && recentOrders.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Order ID</TableHead>
                    <TableHead>Customer</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Amount</TableHead>
                    <TableHead>Date</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentOrders.map((order) => (
                    <TableRow key={order.id}>
                      <TableCell className="font-medium">#{order.id}</TableCell>
                      <TableCell>{order.customer}</TableCell>
                      <TableCell>
                        <StatusBadge status={order.status} />
                      </TableCell>
                      <TableCell className="text-right">{formatPrice(order.total)}</TableCell>
                      <TableCell>{new Date(order.date).toLocaleDateString()}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <div className="h-52 flex flex-col items-center justify-center text-muted-foreground">
                <CreditCard className="h-8 w-8 mb-2 opacity-30" />
                <p>No recent orders found</p>
              </div>
            )}
          </CardContent>
        </Card>
        
        {/* Recent custom requests */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-lg font-medium">Recent Custom Requests</CardTitle>
            <Link href="/admin/custom-requests" className="text-sm text-primary hover:underline flex items-center">
              View all <ChevronRight className="ml-1 h-4 w-4" />
            </Link>
          </CardHeader>
          <CardContent>
            {requestsLoading ? (
              <div className="h-52 flex items-center justify-center">
                <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
              </div>
            ) : recentRequests && recentRequests.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Request ID</TableHead>
                    <TableHead>Customer</TableHead>
                    <TableHead>Product Type</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Date</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentRequests.map((request) => (
                    <TableRow key={request.id}>
                      <TableCell className="font-medium">#{request.id}</TableCell>
                      <TableCell>{request.customer}</TableCell>
                      <TableCell>{request.productType}</TableCell>
                      <TableCell>
                        <StatusBadge status={request.status} />
                      </TableCell>
                      <TableCell>{new Date(request.date).toLocaleDateString()}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <div className="h-52 flex flex-col items-center justify-center text-muted-foreground">
                <MessageSquare className="h-8 w-8 mb-2 opacity-30" />
                <p>No recent custom requests found</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}
