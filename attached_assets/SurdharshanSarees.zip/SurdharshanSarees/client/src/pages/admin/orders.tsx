import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import AdminLayout from "@/components/admin/AdminLayout";
import StatusBadge from "@/components/admin/StatusBadge";
import { formatPrice } from "@/lib/utils";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Pagination } from "@/components/ui/pagination";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import {
  Loader2,
  Search,
  Filter,
  Eye,
  XCircle,
  Package,
} from "lucide-react";

// Order type
interface Order {
  id: number;
  userId: number;
  status: string;
  totalAmount: number;
  shippingAddress: string;
  shippingCity: string;
  shippingState: string;
  shippingPostalCode: string;
  shippingCountry: string;
  paymentMethod: string;
  paymentId?: string;
  isPaid: boolean;
  paidAt?: string;
  isDelivered: boolean;
  deliveredAt?: string;
  createdAt: string;
  updatedAt: string;
  user?: {
    id: number;
    username: string;
    email: string;
    fullName?: string;
  };
  orderItems?: OrderItem[];
}

interface OrderItem {
  id: number;
  orderId: number;
  productId: number;
  quantity: number;
  price: number;
  product?: {
    id: number;
    name: string;
    imageUrl: string;
  };
}

export default function OrdersPage() {
  const { toast } = useToast();
  
  // State for filters and pagination
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [statusToUpdate, setStatusToUpdate] = useState<string>("");
  
  // Get orders with filters
  const {
    data: orderData,
    isLoading,
    isError,
  } = useQuery<{ orders: Order[]; count: number }>({
    queryKey: [
      "/api/admin/orders",
      {
        page: currentPage,
        limit: 10,
        status: statusFilter || undefined,
      },
    ],
  });
  
  // Update order status mutation
  const updateStatusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: number; status: string }) => {
      await apiRequest("PUT", `/api/admin/orders/${id}`, { status });
    },
    onSuccess: () => {
      toast({
        title: "Order Updated",
        description: `Order status has been updated to ${statusToUpdate}`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/orders"] });
      setSelectedOrder(null);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update order: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  const handleStatusChange = (value: string) => {
    setStatusFilter(value);
    setCurrentPage(1);
  };
  
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearch(e.target.value);
    setCurrentPage(1);
  };
  
  const handleUpdateStatus = () => {
    if (selectedOrder && statusToUpdate) {
      updateStatusMutation.mutate({
        id: selectedOrder.id,
        status: statusToUpdate,
      });
    }
  };
  
  const resetFilters = () => {
    setSearch("");
    setStatusFilter("");
    setCurrentPage(1);
  };
  
  // Calculate total pages
  const totalPages = orderData ? Math.ceil(orderData.count / 10) : 1;
  
  // Order statuses for dropdown
  const orderStatuses = [
    { value: "pending", label: "Pending" },
    { value: "processing", label: "Processing" },
    { value: "shipped", label: "Shipped" },
    { value: "delivered", label: "Delivered" },
    { value: "cancelled", label: "Cancelled" },
    { value: "paid", label: "Paid" },
  ];
  
  return (
    <AdminLayout title="Manage Orders">
      <div className="mb-6 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div className="flex items-center space-x-2">
          {(search || statusFilter) && (
            <Button variant="outline" onClick={resetFilters}>
              Clear Filters
            </Button>
          )}
        </div>
        
        <div className="flex flex-col md:flex-row gap-2">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search orders..."
              className="pl-8 w-full md:w-[250px]"
              value={search}
              onChange={handleSearchChange}
            />
          </div>
          
          <Button
            variant="outline"
            size="icon"
            className="md:hidden"
            onClick={() => 
              document.getElementById("order-filters-container")?.classList.toggle("hidden")
            }
          >
            <Filter className="h-4 w-4" />
          </Button>
        </div>
      </div>
      
      <div id="order-filters-container" className="hidden md:flex flex-wrap gap-2 mb-6">
        <Select value={statusFilter} onValueChange={handleStatusChange}>
          <SelectTrigger className="w-full md:w-[180px]">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="">All Statuses</SelectItem>
            {orderStatuses.map((status) => (
              <SelectItem key={status.value} value={status.value}>
                {status.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      
      {isLoading ? (
        <div className="flex items-center justify-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : isError ? (
        <div className="flex flex-col items-center justify-center h-64">
          <XCircle className="h-10 w-10 text-destructive mb-2" />
          <p className="text-lg font-medium">Failed to load orders</p>
          <Button 
            variant="outline" 
            className="mt-4"
            onClick={() => queryClient.invalidateQueries({ queryKey: ["/api/admin/orders"] })}
          >
            Try Again
          </Button>
        </div>
      ) : orderData?.orders.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-64 text-center">
          <div className="mb-4 text-muted-foreground">
            <Package className="h-12 w-12 mx-auto mb-2 opacity-20" />
            <h3 className="text-lg font-medium">No orders found</h3>
          </div>
          <p className="text-sm text-muted-foreground mb-4">
            {statusFilter
              ? "Try adjusting your filters"
              : "No orders have been placed yet"}
          </p>
        </div>
      ) : (
        <>
          <div className="rounded-md border overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Order ID</TableHead>
                  <TableHead>Customer</TableHead>
                  <TableHead className="hidden md:table-cell">Date</TableHead>
                  <TableHead>Total</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {orderData.orders.map((order) => (
                  <TableRow key={order.id}>
                    <TableCell className="font-medium">#{order.id}</TableCell>
                    <TableCell>{order.user?.fullName || order.user?.username || "Guest"}</TableCell>
                    <TableCell className="hidden md:table-cell">
                      {new Date(order.createdAt).toLocaleDateString()}
                    </TableCell>
                    <TableCell>{formatPrice(parseFloat(order.totalAmount.toString()))}</TableCell>
                    <TableCell>
                      <StatusBadge status={order.status} />
                    </TableCell>
                    <TableCell className="text-right">
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={() => setSelectedOrder(order)}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                        </DialogTrigger>
                        {selectedOrder && (
                          <DialogContent className="max-w-3xl">
                            <DialogHeader>
                              <DialogTitle>Order #{selectedOrder.id}</DialogTitle>
                              <DialogDescription>
                                Placed on {new Date(selectedOrder.createdAt).toLocaleDateString()}
                              </DialogDescription>
                            </DialogHeader>
                            
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                              <div>
                                <h3 className="font-medium text-sm mb-2">Customer Information</h3>
                                <div className="bg-muted p-3 rounded-md">
                                  <p><span className="font-medium">Name:</span> {selectedOrder.user?.fullName || selectedOrder.user?.username || "Guest"}</p>
                                  <p><span className="font-medium">Email:</span> {selectedOrder.user?.email || "N/A"}</p>
                                </div>
                              </div>
                              
                              <div>
                                <h3 className="font-medium text-sm mb-2">Shipping Address</h3>
                                <div className="bg-muted p-3 rounded-md">
                                  <p>{selectedOrder.shippingAddress}</p>
                                  <p>{selectedOrder.shippingCity}, {selectedOrder.shippingState} {selectedOrder.shippingPostalCode}</p>
                                  <p>{selectedOrder.shippingCountry}</p>
                                </div>
                              </div>
                            </div>
                            
                            <div className="mt-4">
                              <h3 className="font-medium text-sm mb-2">Order Items</h3>
                              <div className="rounded-md border overflow-hidden">
                                <Table>
                                  <TableHeader>
                                    <TableRow>
                                      <TableHead>Product</TableHead>
                                      <TableHead className="text-right">Quantity</TableHead>
                                      <TableHead className="text-right">Price</TableHead>
                                      <TableHead className="text-right">Subtotal</TableHead>
                                    </TableRow>
                                  </TableHeader>
                                  <TableBody>
                                    {selectedOrder.orderItems?.map((item) => (
                                      <TableRow key={item.id}>
                                        <TableCell>
                                          <div className="flex items-center">
                                            {item.product?.imageUrl && (
                                              <div className="h-10 w-10 rounded overflow-hidden mr-3">
                                                <img
                                                  src={item.product.imageUrl}
                                                  alt={item.product?.name}
                                                  className="h-full w-full object-cover"
                                                />
                                              </div>
                                            )}
                                            <span>{item.product?.name || `Product #${item.productId}`}</span>
                                          </div>
                                        </TableCell>
                                        <TableCell className="text-right">{item.quantity}</TableCell>
                                        <TableCell className="text-right">{formatPrice(parseFloat(item.price.toString()))}</TableCell>
                                        <TableCell className="text-right">{formatPrice(parseFloat(item.price.toString()) * item.quantity)}</TableCell>
                                      </TableRow>
                                    ))}
                                  </TableBody>
                                </Table>
                              </div>
                            </div>
                            
                            <div className="flex flex-col sm:flex-row justify-between mt-4">
                              <div>
                                <h3 className="font-medium text-sm mb-2">Payment Information</h3>
                                <div className="bg-muted p-3 rounded-md">
                                  <p><span className="font-medium">Method:</span> {selectedOrder.paymentMethod}</p>
                                  <p><span className="font-medium">Status:</span> {selectedOrder.isPaid ? "Paid" : "Unpaid"}</p>
                                  {selectedOrder.paidAt && (
                                    <p><span className="font-medium">Paid on:</span> {new Date(selectedOrder.paidAt).toLocaleDateString()}</p>
                                  )}
                                  {selectedOrder.paymentId && (
                                    <p><span className="font-medium">Payment ID:</span> {selectedOrder.paymentId}</p>
                                  )}
                                </div>
                              </div>
                              
                              <div className="mt-4 sm:mt-0">
                                <h3 className="font-medium text-sm mb-2">Order Summary</h3>
                                <div className="bg-muted p-3 rounded-md">
                                  <p className="flex justify-between">
                                    <span>Total:</span>
                                    <span className="font-medium">{formatPrice(parseFloat(selectedOrder.totalAmount.toString()))}</span>
                                  </p>
                                  <p className="flex justify-between">
                                    <span>Status:</span>
                                    <StatusBadge status={selectedOrder.status} />
                                  </p>
                                </div>
                              </div>
                            </div>
                            
                            <DialogFooter className="mt-6">
                              <div className="flex flex-col sm:flex-row gap-4 w-full justify-between">
                                <Select 
                                  value={statusToUpdate} 
                                  onValueChange={setStatusToUpdate}
                                >
                                  <SelectTrigger className="w-full sm:w-[180px]">
                                    <SelectValue placeholder="Update Status" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    {orderStatuses.map((status) => (
                                      <SelectItem key={status.value} value={status.value}>
                                        {status.label}
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                                
                                <div className="flex gap-2">
                                  <DialogClose asChild>
                                    <Button variant="outline">Cancel</Button>
                                  </DialogClose>
                                  <Button
                                    className="bg-primary"
                                    onClick={handleUpdateStatus}
                                    disabled={
                                      !statusToUpdate ||
                                      statusToUpdate === selectedOrder.status ||
                                      updateStatusMutation.isPending
                                    }
                                  >
                                    {updateStatusMutation.isPending ? (
                                      <>
                                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                        Updating...
                                      </>
                                    ) : (
                                      "Update Status"
                                    )}
                                  </Button>
                                </div>
                              </div>
                            </DialogFooter>
                          </DialogContent>
                        )}
                      </Dialog>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          
          {totalPages > 1 && (
            <div className="mt-6 flex justify-center">
              <Pagination
                currentPage={currentPage}
                totalPages={totalPages}
                onPageChange={setCurrentPage}
              />
            </div>
          )}
        </>
      )}
    </AdminLayout>
  );
}
