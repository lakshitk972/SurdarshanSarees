import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link, useLocation } from "wouter";
import AdminLayout from "@/components/admin/AdminLayout";
import { formatPrice } from "@/lib/utils";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Product, Category, Material, WorkType } from "@shared/schema";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Pagination } from "@/components/ui/pagination";
import { Badge } from "@/components/ui/badge";
import {
  PlusCircle,
  Search,
  Edit,
  Trash2,
  CheckCircle,
  XCircle,
  Star,
  Filter,
  Loader2
} from "lucide-react";

export default function ProductsPage() {
  const [_, setLocation] = useLocation();
  const { toast } = useToast();
  
  // State for filters and pagination
  const [search, setSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("");
  const [materialFilter, setMaterialFilter] = useState("");
  const [workTypeFilter, setWorkTypeFilter] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [productToDelete, setProductToDelete] = useState<Product | null>(null);
  
  // Get filter options
  const { data: categories } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });
  
  const { data: materials } = useQuery<Material[]>({
    queryKey: ["/api/materials"],
  });
  
  const { data: workTypes } = useQuery<WorkType[]>({
    queryKey: ["/api/work-types"],
  });
  
  // Get products with filters
  const {
    data: productData,
    isLoading,
    isError,
  } = useQuery<{ products: Product[]; count: number }>({
    queryKey: [
      "/api/products",
      {
        page: currentPage,
        limit: 10,
        search,
        categoryId: categoryFilter || undefined,
        materialId: materialFilter || undefined,
        workTypeId: workTypeFilter || undefined,
      },
    ],
  });
  
  // Delete product mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/admin/products/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Product deleted",
        description: "The product has been deleted successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      setProductToDelete(null);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete product: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  // Feature/unfeature product mutation
  const toggleFeatureMutation = useMutation({
    mutationFn: async ({ id, featured }: { id: number; featured: boolean }) => {
      await apiRequest("PUT", `/api/admin/products/${id}`, { featured });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update product: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  // New/not new product mutation
  const toggleNewMutation = useMutation({
    mutationFn: async ({ id, isNew }: { id: number; isNew: boolean }) => {
      await apiRequest("PUT", `/api/admin/products/${id}`, { isNew });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update product: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearch(e.target.value);
    setCurrentPage(1);
  };
  
  const handleCategoryChange = (value: string) => {
    setCategoryFilter(value);
    setCurrentPage(1);
  };
  
  const handleMaterialChange = (value: string) => {
    setMaterialFilter(value);
    setCurrentPage(1);
  };
  
  const handleWorkTypeChange = (value: string) => {
    setWorkTypeFilter(value);
    setCurrentPage(1);
  };
  
  const handleDeleteProduct = () => {
    if (productToDelete) {
      deleteMutation.mutate(productToDelete.id);
    }
  };
  
  const handleToggleFeature = (product: Product) => {
    toggleFeatureMutation.mutate({
      id: product.id,
      featured: !product.featured,
    });
  };
  
  const handleToggleNew = (product: Product) => {
    toggleNewMutation.mutate({
      id: product.id,
      isNew: !product.isNew,
    });
  };
  
  const handleEditProduct = (id: number) => {
    setLocation(`/admin/products/edit/${id}`);
  };
  
  const resetFilters = () => {
    setSearch("");
    setCategoryFilter("");
    setMaterialFilter("");
    setWorkTypeFilter("");
    setCurrentPage(1);
  };
  
  // Calculate total pages
  const totalPages = productData ? Math.ceil(productData.count / 10) : 1;
  
  return (
    <AdminLayout title="Manage Products">
      <div className="mb-6 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div className="flex items-center space-x-2">
          <Link href="/admin/products/add">
            <Button className="bg-primary">
              <PlusCircle className="mr-2 h-4 w-4" /> Add New Product
            </Button>
          </Link>
          {(search || categoryFilter || materialFilter || workTypeFilter) && (
            <Button variant="outline" onClick={resetFilters}>
              Clear Filters
            </Button>
          )}
        </div>
        
        <div className="flex flex-col md:flex-row gap-2">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search products..."
              className="pl-8 w-full md:w-[250px]"
              value={search}
              onChange={handleSearchChange}
            />
          </div>
          
          <Button
            variant="outline"
            size="icon"
            className="md:hidden"
            onClick={() => 
              document.getElementById("filters-container")?.classList.toggle("hidden")
            }
          >
            <Filter className="h-4 w-4" />
          </Button>
        </div>
      </div>
      
      <div id="filters-container" className="hidden md:flex flex-wrap gap-2 mb-6">
        <Select value={categoryFilter} onValueChange={handleCategoryChange}>
          <SelectTrigger className="w-full md:w-[180px]">
            <SelectValue placeholder="Category" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="">All Categories</SelectItem>
            {categories?.map((category) => (
              <SelectItem key={category.id} value={category.id.toString()}>
                {category.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        
        <Select value={materialFilter} onValueChange={handleMaterialChange}>
          <SelectTrigger className="w-full md:w-[180px]">
            <SelectValue placeholder="Material" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="">All Materials</SelectItem>
            {materials?.map((material) => (
              <SelectItem key={material.id} value={material.id.toString()}>
                {material.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        
        <Select value={workTypeFilter} onValueChange={handleWorkTypeChange}>
          <SelectTrigger className="w-full md:w-[180px]">
            <SelectValue placeholder="Work Type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="">All Work Types</SelectItem>
            {workTypes?.map((workType) => (
              <SelectItem key={workType.id} value={workType.id.toString()}>
                {workType.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      
      {isLoading ? (
        <div className="flex items-center justify-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : isError ? (
        <div className="flex flex-col items-center justify-center h-64">
          <XCircle className="h-10 w-10 text-destructive mb-2" />
          <p className="text-lg font-medium">Failed to load products</p>
          <Button 
            variant="outline" 
            className="mt-4"
            onClick={() => queryClient.invalidateQueries({ queryKey: ["/api/products"] })}
          >
            Try Again
          </Button>
        </div>
      ) : productData?.products.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-64 text-center">
          <div className="mb-4 text-muted-foreground">
            <ShoppingBag className="h-12 w-12 mx-auto mb-2 opacity-20" />
            <h3 className="text-lg font-medium">No products found</h3>
          </div>
          <p className="text-sm text-muted-foreground mb-4">
            {search || categoryFilter || materialFilter || workTypeFilter
              ? "Try adjusting your filters"
              : "Get started by adding your first product"}
          </p>
          <Link href="/admin/products/add">
            <Button className="bg-primary">
              <PlusCircle className="mr-2 h-4 w-4" /> Add New Product
            </Button>
          </Link>
        </div>
      ) : (
        <>
          <div className="rounded-md border overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Image</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead className="hidden md:table-cell">Category</TableHead>
                  <TableHead>Price</TableHead>
                  <TableHead className="hidden md:table-cell">Stock</TableHead>
                  <TableHead className="hidden lg:table-cell">Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {productData.products.map((product) => (
                  <TableRow key={product.id}>
                    <TableCell>
                      <div className="h-12 w-12 rounded-md overflow-hidden">
                        <img
                          src={product.imageUrl}
                          alt={product.name}
                          className="h-full w-full object-cover"
                        />
                      </div>
                    </TableCell>
                    <TableCell className="font-medium">{product.name}</TableCell>
                    <TableCell className="hidden md:table-cell">
                      {categories?.find(c => c.id === product.categoryId)?.name || "N/A"}
                    </TableCell>
                    <TableCell>{formatPrice(parseFloat(product.price.toString()))}</TableCell>
                    <TableCell className="hidden md:table-cell">
                      {product.stock > 0 ? (
                        <Badge variant="outline" className="bg-emerald text-white">
                          In Stock ({product.stock})
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="bg-destructive text-white">
                          Out of Stock
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell className="hidden lg:table-cell">
                      <div className="flex space-x-1">
                        {product.featured && (
                          <Badge className="bg-primary text-white">Featured</Badge>
                        )}
                        {product.isNew && (
                          <Badge className="bg-emerald text-white">New</Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="outline"
                          size="icon"
                          title={product.featured ? "Remove from featured" : "Add to featured"}
                          onClick={() => handleToggleFeature(product)}
                        >
                          <Star
                            className={`h-4 w-4 ${
                              product.featured ? "fill-yellow-400 text-yellow-400" : ""
                            }`}
                          />
                        </Button>
                        <Button
                          variant="outline"
                          size="icon"
                          title={product.isNew ? "Remove from new arrivals" : "Add to new arrivals"}
                          onClick={() => handleToggleNew(product)}
                        >
                          <Badge className="h-3 w-3 p-0 text-[0.6rem]">
                            {product.isNew ? "NEW" : "OLD"}
                          </Badge>
                        </Button>
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={() => handleEditProduct(product.id)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button
                              variant="outline"
                              size="icon"
                              className="text-destructive"
                              onClick={() => setProductToDelete(product)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                              <AlertDialogDescription>
                                This will permanently delete the product "{productToDelete?.name}".
                                This action cannot be undone.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel onClick={() => setProductToDelete(null)}>
                                Cancel
                              </AlertDialogCancel>
                              <AlertDialogAction
                                onClick={handleDeleteProduct}
                                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                              >
                                {deleteMutation.isPending ? (
                                  <>
                                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                    Deleting...
                                  </>
                                ) : (
                                  "Delete"
                                )}
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          
          {totalPages > 1 && (
            <div className="mt-6 flex justify-center">
              <Pagination
                currentPage={currentPage}
                totalPages={totalPages}
                onPageChange={setCurrentPage}
              />
            </div>
          )}
        </>
      )}
    </AdminLayout>
  );
}
