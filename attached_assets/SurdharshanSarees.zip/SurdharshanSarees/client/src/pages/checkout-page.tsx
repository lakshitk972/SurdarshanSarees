import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { useCart } from "@/hooks/use-cart";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { formatPrice } from "@/lib/utils";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  ShoppingBag,
  CreditCard,
  Truck,
  CheckCircle,
  Loader2,
  ArrowLeft,
  Smartphone
} from "lucide-react";
import { CartItem } from "@/components/ui/cart-item";
import PhonePeButton from "@/components/PhonePeButton";

// Schema for shipping information
const shippingSchema = z.object({
  fullName: z.string().min(3, "Full name must be at least 3 characters"),
  email: z.string().email("Must provide a valid email"),
  phone: z.string().min(10, "Phone number must be at least 10 characters"),
  address: z.string().min(5, "Address must be at least 5 characters"),
  city: z.string().min(2, "City must be at least 2 characters"),
  state: z.string().min(2, "State must be at least 2 characters"),
  postalCode: z.string().min(5, "Postal code must be at least 5 characters"),
  country: z.string().min(2, "Country must be at least 2 characters"),
  paymentMethod: z.string().min(1, "Please select a payment method"),
  notes: z.string().optional(),
});

type ShippingFormValues = z.infer<typeof shippingSchema>;

// Checkout steps
type CheckoutStep = "shipping" | "payment" | "phonepe" | "confirmation";

export default function CheckoutPage() {
  const [_, setLocation] = useLocation();
  const { user } = useAuth();
  const { items, subtotal, clearCart } = useCart();
  const { toast } = useToast();
  const [currentStep, setCurrentStep] = useState<CheckoutStep>("shipping");
  
  // If no items in cart, redirect to collections
  if (items.length === 0) {
    setLocation("/collections");
    return null;
  }
  
  // Form setup
  const form = useForm<ShippingFormValues>({
    resolver: zodResolver(shippingSchema),
    defaultValues: {
      fullName: user?.fullName || "",
      email: user?.email || "",
      phone: "",
      address: "",
      city: "",
      state: "",
      postalCode: "",
      country: "India",
      paymentMethod: "cod",
      notes: "",
    },
  });
  
  // Prepare order items for API
  const orderItems = items.map((item) => ({
    productId: item.product.id,
    quantity: item.quantity,
    price: parseFloat(item.product.price.toString()),
  }));
  
  // Create order mutation
  const createOrderMutation = useMutation({
    mutationFn: async (data: ShippingFormValues) => {
      const orderData = {
        totalAmount: subtotal,
        shippingAddress: data.address,
        shippingCity: data.city,
        shippingState: data.state,
        shippingPostalCode: data.postalCode,
        shippingCountry: data.country,
        paymentMethod: data.paymentMethod,
        orderItems,
      };
      
      const res = await apiRequest("POST", "/api/orders", orderData);
      return res.json();
    },
    onSuccess: () => {
      setCurrentStep("confirmation");
      clearCart();
      toast({
        title: "Order Placed",
        description: "Your order has been placed successfully!",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to place order: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  const onSubmit = (values: ShippingFormValues) => {
    // Simple validation to ensure cart is not empty
    if (items.length === 0) {
      toast({
        title: "Cart is empty",
        description: "Please add items to your cart before checkout",
        variant: "destructive",
      });
      return;
    }
    
    // Move to payment step if on shipping step
    if (currentStep === "shipping") {
      setCurrentStep("payment");
      return;
    }
    
    // Process order based on payment method
    if (currentStep === "payment") {
      if (values.paymentMethod === "phonepe") {
        // Move to PhonePe payment screen
        setCurrentStep("phonepe");
      } else {
        // For COD or other payment methods
        createOrderMutation.mutate(values);
      }
    }
  };
  
  return (
    <div className="bg-background py-12 px-4 md:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Checkout heading */}
        <div className="mb-8 text-center">
          <h1 className="font-playfair text-3xl md:text-4xl font-bold text-charcoal mb-2">
            Checkout
          </h1>
          <p className="font-poppins text-gray-600">
            Complete your purchase by providing your shipping and payment details
          </p>
        </div>
        
        {/* Checkout steps */}
        <div className="mb-10">
          <div className="flex justify-center">
            <div className="flex items-center w-full max-w-2xl">
              <div className="flex flex-col items-center flex-1">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                  currentStep === "shipping" ? "bg-primary text-white" : "bg-primary/20 text-primary"
                }`}>
                  <Truck size={20} />
                </div>
                <span className="text-sm mt-2">Shipping</span>
              </div>
              <div className={`h-1 flex-1 ${
                currentStep === "shipping" ? "bg-gray-200" : "bg-primary/50"
              }`}></div>
              <div className="flex flex-col items-center flex-1">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                  currentStep === "payment" || currentStep === "phonepe" ? "bg-primary text-white" : currentStep === "confirmation" ? "bg-primary/20 text-primary" : "bg-gray-200 text-gray-500"
                }`}>
                  <CreditCard size={20} />
                </div>
                <span className="text-sm mt-2">Payment</span>
              </div>
              <div className={`h-1 flex-1 ${
                currentStep === "confirmation" || currentStep === "phonepe" ? "bg-primary/50" : "bg-gray-200"
              }`}></div>
              <div className="flex flex-col items-center flex-1">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                  currentStep === "confirmation" ? "bg-primary text-white" : "bg-gray-200 text-gray-500"
                }`}>
                  <CheckCircle size={20} />
                </div>
                <span className="text-sm mt-2">Confirmation</span>
              </div>
            </div>
          </div>
        </div>
        
        {/* Main content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left section - Form */}
          <div className="lg:col-span-2">
            {currentStep === "phonepe" && (
              <Card>
                <CardHeader>
                  <CardTitle>PhonePe Payment</CardTitle>
                  <CardDescription>
                    Complete your payment securely via PhonePe
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex flex-col items-center justify-center py-10">
                  <div className="w-full max-w-md mx-auto">
                    <PhonePeButton 
                      amount={subtotal}
                      customerData={{
                        name: form.getValues("fullName"),
                        email: form.getValues("email"),
                        phone: form.getValues("phone")
                      }}
                      onSuccess={(data) => {
                        // Create order with payment info
                        const orderData = {
                          ...form.getValues(),
                          totalAmount: subtotal,
                          paymentId: data.paymentId,
                          paymentMethod: "phonepe",
                          orderItems
                        };
                        
                        // Make API call to create order
                        const createOrderWithPayment = async () => {
                          try {
                            const res = await apiRequest("POST", "/api/orders", orderData);
                            const data = await res.json();
                            
                            // Handle success
                            setCurrentStep("confirmation");
                            clearCart();
                            toast({
                              title: "Order Placed",
                              description: "Your order has been placed successfully!",
                            });
                          } catch (error: any) {
                            toast({
                              title: "Error",
                              description: `Failed to place order: ${error.message}`,
                              variant: "destructive",
                            });
                          }
                        };
                        
                        createOrderWithPayment();
                      }}
                      onFailure={(error) => {
                        toast({
                          title: "Payment Failed",
                          description: error,
                          variant: "destructive",
                        });
                      }}
                    />
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button 
                    variant="outline" 
                    onClick={() => setCurrentStep("payment")}
                  >
                    <ArrowLeft className="mr-2 h-4 w-4" /> Back to Payment Options
                  </Button>
                </CardFooter>
              </Card>
            )}
            
            {currentStep === "shipping" && (
              <Card>
                <CardHeader>
                  <CardTitle>Shipping Information</CardTitle>
                  <CardDescription>
                    Enter your shipping details to proceed
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Form {...form}>
                    <form className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="fullName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Full Name</FormLabel>
                              <FormControl>
                                <Input placeholder="John Doe" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="email"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Email</FormLabel>
                              <FormControl>
                                <Input type="email" placeholder="john@example.com" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <FormField
                        control={form.control}
                        name="phone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Phone Number</FormLabel>
                            <FormControl>
                              <Input placeholder="+91 98765 43210" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="address"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Address</FormLabel>
                            <FormControl>
                              <Textarea placeholder="Street address, apartment, suite, etc." {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="city"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>City</FormLabel>
                              <FormControl>
                                <Input placeholder="New Delhi" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="state"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>State</FormLabel>
                              <FormControl>
                                <Input placeholder="Delhi" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="postalCode"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Postal Code</FormLabel>
                              <FormControl>
                                <Input placeholder="110001" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="country"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Country</FormLabel>
                              <FormControl>
                                <Input placeholder="India" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <FormField
                        control={form.control}
                        name="notes"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Order Notes (Optional)</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder="Special instructions for delivery or any other information" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </form>
                  </Form>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button 
                    variant="outline" 
                    onClick={() => setLocation("/collections")}
                  >
                    <ArrowLeft className="mr-2 h-4 w-4" /> Continue Shopping
                  </Button>
                  <Button 
                    className="bg-primary"
                    onClick={form.handleSubmit(onSubmit)}
                  >
                    Continue to Payment
                  </Button>
                </CardFooter>
              </Card>
            )}
            
            {currentStep === "payment" && (
              <Card>
                <CardHeader>
                  <CardTitle>Payment Method</CardTitle>
                  <CardDescription>
                    Select your preferred payment method
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Form {...form}>
                    <form className="space-y-6">
                      <FormField
                        control={form.control}
                        name="paymentMethod"
                        render={({ field }) => (
                          <FormItem>
                            <FormControl>
                              <div className="space-y-4">
                                <div
                                  className={`rounded-lg border p-4 cursor-pointer ${
                                    field.value === "cod" ? "border-primary bg-primary/5" : "border-border"
                                  }`}
                                  onClick={() => field.onChange("cod")}
                                >
                                  <div className="flex items-center justify-between">
                                    <div className="flex items-center space-x-3">
                                      <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                                        field.value === "cod" ? "border-primary" : "border-gray-400"
                                      }`}>
                                        {field.value === "cod" && (
                                          <div className="w-3 h-3 rounded-full bg-primary"></div>
                                        )}
                                      </div>
                                      <div>
                                        <p className="font-medium">Cash on Delivery</p>
                                        <p className="text-sm text-gray-500">Pay when you receive your order</p>
                                      </div>
                                    </div>
                                    <CreditCard className="h-6 w-6 text-gray-400" />
                                  </div>
                                </div>
                                
                                <div
                                  className={`rounded-lg border p-4 cursor-pointer ${
                                    field.value === "card" ? "border-primary bg-primary/5" : "border-border"
                                  }`}
                                  onClick={() => field.onChange("card")}
                                >
                                  <div className="flex items-center justify-between">
                                    <div className="flex items-center space-x-3">
                                      <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                                        field.value === "card" ? "border-primary" : "border-gray-400"
                                      }`}>
                                        {field.value === "card" && (
                                          <div className="w-3 h-3 rounded-full bg-primary"></div>
                                        )}
                                      </div>
                                      <div>
                                        <p className="font-medium">Credit/Debit Card</p>
                                        <p className="text-sm text-gray-500">Pay using your card (Processing currently disabled)</p>
                                      </div>
                                    </div>
                                    <CreditCard className="h-6 w-6 text-gray-400" />
                                  </div>
                                </div>
                                
                                <div
                                  className={`rounded-lg border p-4 cursor-pointer ${
                                    field.value === "phonepe" ? "border-primary bg-primary/5" : "border-border"
                                  }`}
                                  onClick={() => field.onChange("phonepe")}
                                >
                                  <div className="flex items-center justify-between">
                                    <div className="flex items-center space-x-3">
                                      <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                                        field.value === "phonepe" ? "border-primary" : "border-gray-400"
                                      }`}>
                                        {field.value === "phonepe" && (
                                          <div className="w-3 h-3 rounded-full bg-primary"></div>
                                        )}
                                      </div>
                                      <div>
                                        <p className="font-medium">PhonePe (Online Payment)</p>
                                        <p className="text-sm text-gray-500">Pay securely online with UPI, cards, wallets & more</p>
                                      </div>
                                    </div>
                                    <Smartphone className="h-6 w-6 text-gray-400" />
                                  </div>
                                </div>
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </form>
                  </Form>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button 
                    variant="outline" 
                    onClick={() => setCurrentStep("shipping")}
                  >
                    <ArrowLeft className="mr-2 h-4 w-4" /> Back to Shipping
                  </Button>
                  <Button 
                    className="bg-primary"
                    onClick={form.handleSubmit(onSubmit)}
                    disabled={createOrderMutation.isPending}
                  >
                    {createOrderMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      "Place Order"
                    )}
                  </Button>
                </CardFooter>
              </Card>
            )}
            
            {currentStep === "confirmation" && (
              <Card>
                <CardHeader className="text-center">
                  <div className="mx-auto mb-4">
                    <CheckCircle className="h-16 w-16 text-emerald mx-auto" />
                  </div>
                  <CardTitle>Order Confirmed!</CardTitle>
                  <CardDescription>
                    Thank you for your purchase. Your order has been placed successfully.
                  </CardDescription>
                </CardHeader>
                <CardContent className="text-center">
                  <p className="mb-6">
                    We have sent a confirmation email to {form.getValues("email")} with your order details.
                    Your items will be shipped to the address you provided.
                  </p>
                  
                  <div className="border-t border-b py-4 px-4 my-6">
                    <p className="font-medium">Estimated Delivery</p>
                    <p className="text-lg text-primary font-medium mt-1">
                      {new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toLocaleDateString("en-IN", {
                        year: "numeric",
                        month: "long",
                        day: "numeric",
                      })}
                    </p>
                  </div>
                </CardContent>
                <CardFooter className="justify-center">
                  <Button 
                    className="bg-primary px-8"
                    onClick={() => setLocation("/collections")}
                  >
                    Continue Shopping
                  </Button>
                </CardFooter>
              </Card>
            )}
          </div>
          
          {/* Right section - Order summary */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>Order Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="max-h-[300px] overflow-y-auto space-y-3 pr-2">
                  {items.map((item) => (
                    <div key={item.product.id} className="border-b pb-3">
                      <div className="flex items-start">
                        <div className="w-16 h-16 rounded overflow-hidden mr-3">
                          <img
                            src={item.product.imageUrl}
                            alt={item.product.name}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="flex-1">
                          <h4 className="font-medium">{item.product.name}</h4>
                          <p className="text-sm text-gray-500">Qty: {item.quantity}</p>
                          <p className="text-primary font-medium">
                            {formatPrice(parseFloat(item.product.price.toString()) * item.quantity)}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                
                <div className="border-t pt-4">
                  <div className="flex justify-between mb-2">
                    <span className="text-gray-600">Subtotal</span>
                    <span>{formatPrice(subtotal)}</span>
                  </div>
                  <div className="flex justify-between mb-2">
                    <span className="text-gray-600">Shipping</span>
                    <span>Free</span>
                  </div>
                  <div className="flex justify-between font-semibold text-lg border-t mt-2 pt-2">
                    <span>Total</span>
                    <span className="text-primary">{formatPrice(subtotal)}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {currentStep !== "confirmation" && (
              <div className="mt-6">
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex items-start mb-4">
                      <div className="bg-primary/10 p-2 rounded-full mr-4">
                        <Truck className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-medium">Free Shipping</h3>
                        <p className="text-sm text-gray-500">
                          For all orders across India
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-start">
                      <div className="bg-primary/10 p-2 rounded-full mr-4">
                        <ShoppingBag className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-medium">Secure Shopping</h3>
                        <p className="text-sm text-gray-500">
                          We protect your payment information
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
