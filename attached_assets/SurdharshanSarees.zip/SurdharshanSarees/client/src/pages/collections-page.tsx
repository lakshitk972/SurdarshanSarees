import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { Category, Material, WorkType, Product } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ProductCard } from "@/components/ui/product-card";
import { Pagination } from "@/components/ui/pagination";
import { Loader2 } from "lucide-react";

export default function CollectionsPage() {
  const [_, params] = useRoute<{ category: string }>("/collections/:category");
  const categorySlug = params?.category || "";
  
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [selectedMaterial, setSelectedMaterial] = useState<string>("");
  const [selectedWorkType, setSelectedWorkType] = useState<string>("");
  const [priceRange, setPriceRange] = useState<string>("");
  const [currentPage, setCurrentPage] = useState(1);
  const productsPerPage = 12;
  
  // Fetch filter data
  const { data: categories } = useQuery<Category[]>({ queryKey: ["/api/categories"] });
  const { data: materials } = useQuery<Material[]>({ queryKey: ["/api/materials"] });
  const { data: workTypes } = useQuery<WorkType[]>({ queryKey: ["/api/work-types"] });
  
  // Parse price range to min and max values
  const getPriceRangeValues = (range: string) => {
    if (!range) return { min: undefined, max: undefined };
    
    const [min, max] = range.split("-").map(val => parseInt(val));
    return { min, max };
  };
  
  // Set default category from URL
  useEffect(() => {
    if (categorySlug && categories) {
      const category = categories.find(c => c.slug === categorySlug);
      if (category) {
        setSelectedCategory(category.id.toString());
      }
    }
  }, [categorySlug, categories]);
  
  // Fetch products with filters
  const { data: productData, isLoading: productsLoading } = useQuery<{products: Product[], count: number}>({
    queryKey: [
      "/api/products", 
      {
        page: currentPage,
        limit: productsPerPage,
        categoryId: selectedCategory || undefined,
        materialId: selectedMaterial || undefined,
        workTypeId: selectedWorkType || undefined,
        minPrice: getPriceRangeValues(priceRange).min,
        maxPrice: getPriceRangeValues(priceRange).max,
      }
    ],
  });
  
  const products = productData?.products || [];
  const totalProducts = productData?.count || 0;
  const totalPages = Math.ceil(totalProducts / productsPerPage);
  
  const handleCategoryChange = (value: string) => {
    setSelectedCategory(value);
    setCurrentPage(1);
  };
  
  const handleMaterialChange = (value: string) => {
    setSelectedMaterial(value);
    setCurrentPage(1);
  };
  
  const handleWorkTypeChange = (value: string) => {
    setSelectedWorkType(value);
    setCurrentPage(1);
  };
  
  const handlePriceRangeChange = (value: string) => {
    setPriceRange(value);
    setCurrentPage(1);
  };
  
  return (
    <section className="py-16 px-6 md:px-12 lg:px-24 bg-background">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="font-playfair text-3xl md:text-4xl font-bold text-charcoal mb-4">
            Our Exclusive Collections
          </h1>
          <p className="font-poppins text-gray-600 max-w-2xl mx-auto">
            Browse through our meticulously crafted pieces, showcasing the finest materials and expert artisanship.
          </p>
        </div>
        
        {/* Collection Filters */}
        <div className="mb-10">
          <div className="flex flex-wrap justify-center gap-3 mb-6">
            <Button 
              variant={!selectedCategory ? "default" : "outline"}
              onClick={() => handleCategoryChange("")}
              className="font-poppins font-medium"
            >
              All Collections
            </Button>
            
            {categories?.map(category => (
              <Button 
                key={category.id}
                variant={selectedCategory === category.id.toString() ? "default" : "outline"}
                onClick={() => handleCategoryChange(category.id.toString())}
                className="font-poppins font-medium"
              >
                {category.name}
              </Button>
            ))}
          </div>
          
          <div className="flex flex-wrap justify-center gap-6">
            <div className="w-full md:w-auto">
              <Select
                value={priceRange}
                onValueChange={handlePriceRangeChange}
              >
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="Price Range" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All Prices</SelectItem>
                  <SelectItem value="5000-15000">₹5,000 - ₹15,000</SelectItem>
                  <SelectItem value="15000-25000">₹15,000 - ₹25,000</SelectItem>
                  <SelectItem value="25000-40000">₹25,000 - ₹40,000</SelectItem>
                  <SelectItem value="40000-50000">₹40,000+</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="w-full md:w-auto">
              <Select
                value={selectedMaterial}
                onValueChange={handleMaterialChange}
              >
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="Material" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All Materials</SelectItem>
                  {materials?.map(material => (
                    <SelectItem key={material.id} value={material.id.toString()}>
                      {material.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="w-full md:w-auto">
              <Select
                value={selectedWorkType}
                onValueChange={handleWorkTypeChange}
              >
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="Work Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All Work Types</SelectItem>
                  {workTypes?.map(workType => (
                    <SelectItem key={workType.id} value={workType.id.toString()}>
                      {workType.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
        
        {/* Products Grid */}
        {productsLoading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          products.length === 0 ? (
            <div className="text-center py-20">
              <h3 className="font-playfair text-xl font-semibold mb-2">No products found</h3>
              <p className="text-gray-500">Try adjusting your filters to find what you're looking for.</p>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-12 animate-slideUp">
                {products.map(product => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
              
              {totalPages > 1 && (
                <div className="flex justify-center mt-8">
                  <Pagination
                    currentPage={currentPage}
                    totalPages={totalPages}
                    onPageChange={setCurrentPage}
                  />
                </div>
              )}
            </>
          )
        )}
      </div>
    </section>
  );
}
