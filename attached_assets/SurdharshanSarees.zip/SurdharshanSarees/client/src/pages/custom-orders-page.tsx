import { useState, useRef } from "react";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { InsertCustomRequest } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { 
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage
} from "@/components/ui/form";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Gem, HandHelping, Crown, CalendarCheck, Upload } from "lucide-react";

const customRequestSchema = z.object({
  fullName: z.string().min(3, "Full name must be at least 3 characters"),
  email: z.string().email("Must provide a valid email"),
  phone: z.string().min(10, "Phone number must be at least 10 characters"),
  productType: z.string().min(1, "Please select a product type"),
  materials: z.string().min(1, "Please select at least one material"),
  workTypes: z.string().min(1, "Please select at least one work type"),
  budgetRange: z.string().min(1, "Please select a budget range"),
  requirements: z.string().optional(),
  referenceImages: z.string().optional(),
});

type FormValues = z.infer<typeof customRequestSchema>;

export default function CustomOrdersPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [selectedMaterials, setSelectedMaterials] = useState<string[]>([]);
  const [selectedWorkTypes, setSelectedWorkTypes] = useState<string[]>([]);
  
  const form = useForm<FormValues>({
    resolver: zodResolver(customRequestSchema),
    defaultValues: {
      fullName: user?.fullName || "",
      email: user?.email || "",
      phone: "",
      productType: "",
      materials: "",
      workTypes: "",
      budgetRange: "",
      requirements: "",
      referenceImages: "",
    },
  });
  
  const materials = [
    { id: "ghazi_silk", label: "Ghazi Silk" },
    { id: "banarasi", label: "Banarasi" },
    { id: "bandni", label: "Bandni" },
    { id: "pure_silk", label: "Pure Silk" },
    { id: "georgette", label: "Georgette" },
    { id: "other", label: "Other" },
  ];
  
  const workTypes = [
    { id: "gotta_patti", label: "Gotta Patti" },
    { id: "jardoji", label: "Jardoji" },
    { id: "hand_embroidery", label: "Hand Embroidery" },
    { id: "zari_work", label: "Zari Work" },
    { id: "stone_work", label: "Stone Work" },
    { id: "other", label: "Other" },
  ];
  
  const submitMutation = useMutation({
    mutationFn: async (data: InsertCustomRequest) => {
      const res = await apiRequest("POST", "/api/custom-requests", data);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Request Submitted",
        description: "Your custom order request has been submitted successfully. We'll get back to you soon!",
      });
      form.reset();
      setSelectedMaterials([]);
      setSelectedWorkTypes([]);
    },
    onError: (error) => {
      toast({
        title: "Submission Failed",
        description: error.message || "Failed to submit your request. Please try again.",
        variant: "destructive",
      });
    },
  });
  
  const handleMaterialChange = (checked: boolean, materialId: string) => {
    if (checked) {
      setSelectedMaterials([...selectedMaterials, materialId]);
    } else {
      setSelectedMaterials(selectedMaterials.filter(id => id !== materialId));
    }
  };
  
  const handleWorkTypeChange = (checked: boolean, workTypeId: string) => {
    if (checked) {
      setSelectedWorkTypes([...selectedWorkTypes, workTypeId]);
    } else {
      setSelectedWorkTypes(selectedWorkTypes.filter(id => id !== workTypeId));
    }
  };
  
  const onSubmit = (values: FormValues) => {
    // Convert arrays to comma-separated strings
    const data = {
      ...values,
      materials: selectedMaterials.join(", "),
      workTypes: selectedWorkTypes.join(", "),
    };
    
    submitMutation.mutate(data);
  };
  
  // Handle file selection (mock for now)
  const handleFileButtonClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };
  
  return (
    <section className="py-16 px-6 md:px-12 lg:px-24 bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="order-2 lg:order-1">
            <div className="bg-background p-8 rounded-lg shadow-md">
              <h3 className="font-playfair text-2xl md:text-3xl font-bold text-charcoal mb-6">
                Request Custom Design
              </h3>
              <p className="font-poppins text-gray-600 mb-6">
                Let our master craftsmen create a unique piece for your special occasion. 
                Fill the form below with your requirements.
              </p>
              
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="fullName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Full Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Your name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email Address</FormLabel>
                          <FormControl>
                            <Input type="email" placeholder="Your email" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Phone Number</FormLabel>
                          <FormControl>
                            <Input placeholder="Your phone number" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="productType"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Product Type</FormLabel>
                          <Select 
                            onValueChange={field.onChange} 
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select Product Type" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="saree">Saree</SelectItem>
                              <SelectItem value="lehenga">Lehenga</SelectItem>
                              <SelectItem value="bridal_set">Bridal Set</SelectItem>
                              <SelectItem value="other">Other</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={form.control}
                    name="materials"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Preferred Material</FormLabel>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                          {materials.map((material) => (
                            <div className="flex items-center space-x-2" key={material.id}>
                              <Checkbox
                                id={`material-${material.id}`}
                                checked={selectedMaterials.includes(material.id)}
                                onCheckedChange={(checked) => {
                                  handleMaterialChange(checked as boolean, material.id);
                                  field.onChange(selectedMaterials.join(", "));
                                }}
                              />
                              <label
                                htmlFor={`material-${material.id}`}
                                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                              >
                                {material.label}
                              </label>
                            </div>
                          ))}
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="workTypes"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Preferred Work Type</FormLabel>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                          {workTypes.map((workType) => (
                            <div className="flex items-center space-x-2" key={workType.id}>
                              <Checkbox
                                id={`worktype-${workType.id}`}
                                checked={selectedWorkTypes.includes(workType.id)}
                                onCheckedChange={(checked) => {
                                  handleWorkTypeChange(checked as boolean, workType.id);
                                  field.onChange(selectedWorkTypes.join(", "));
                                }}
                              />
                              <label
                                htmlFor={`worktype-${workType.id}`}
                                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                              >
                                {workType.label}
                              </label>
                            </div>
                          ))}
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="budgetRange"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Budget Range</FormLabel>
                        <Select 
                          onValueChange={field.onChange} 
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select Budget Range" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="5000-15000">₹5,000 - ₹15,000</SelectItem>
                            <SelectItem value="15000-25000">₹15,000 - ₹25,000</SelectItem>
                            <SelectItem value="25000-40000">₹25,000 - ₹40,000</SelectItem>
                            <SelectItem value="40000-50000">₹40,000 - ₹50,000</SelectItem>
                            <SelectItem value="50000+">Above ₹50,000</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="requirements"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Additional Requirements</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Please describe your requirements in detail" 
                            className="resize-none" 
                            rows={4}
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="referenceImages"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Upload Reference Images (Optional)</FormLabel>
                        <div className="border-2 border-dashed border-gray-300 rounded-md p-6 text-center">
                          <div className="mb-3">
                            <Upload className="h-8 w-8 mx-auto text-gray-400" />
                          </div>
                          <p className="text-sm text-gray-500 mb-2">
                            Drag and drop files here or click to browse
                          </p>
                          <Button 
                            type="button" 
                            variant="outline"
                            onClick={handleFileButtonClick}
                          >
                            Browse Files
                          </Button>
                          <input 
                            type="file" 
                            className="hidden" 
                            multiple 
                            ref={fileInputRef}
                            onChange={(e) => {
                              // In a real implementation, you'd handle file uploads
                              const files = e.target.files;
                              if (files && files.length > 0) {
                                field.onChange(`${files.length} files selected`);
                              }
                            }}
                          />
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <Button 
                    type="submit" 
                    className="w-full py-6 bg-primary hover:bg-primary/90 text-white font-poppins font-medium rounded-md transition-colors duration-300 flex items-center justify-center"
                    disabled={submitMutation.isPending}
                  >
                    {submitMutation.isPending ? "Submitting..." : "Submit Request"}
                  </Button>
                </form>
              </Form>
            </div>
          </div>
          
          <div className="order-1 lg:order-2">
            <h2 className="font-playfair text-3xl md:text-4xl font-bold text-charcoal mb-6">
              Custom-Made Elegance
            </h2>
            <p className="font-poppins text-gray-600 mb-6">
              At Surdharshan Designer, we specialize in creating bespoke sarees and lehengas that 
              reflect your unique style and preferences. Our master artisans combine traditional 
              craftsmanship with contemporary designs to create exquisite pieces for your special occasions.
            </p>
            
            <div className="space-y-6">
              <div className="flex items-start">
                <div className="bg-primary/10 p-3 rounded-full mr-4">
                  <Gem className="text-primary" />
                </div>
                <div>
                  <h3 className="font-playfair font-semibold text-lg text-charcoal mb-1">
                    Premium Materials
                  </h3>
                  <p className="font-poppins text-gray-600">
                    We source the finest fabrics and materials from across India to ensure exceptional quality.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="bg-primary/10 p-3 rounded-full mr-4">
                  <HandHelping className="text-primary" />
                </div>
                <div>
                  <h3 className="font-playfair font-semibold text-lg text-charcoal mb-1">
                    Expert Craftsmanship
                  </h3>
                  <p className="font-poppins text-gray-600">
                    Each piece is meticulously handcrafted by skilled artisans with decades of experience.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="bg-primary/10 p-3 rounded-full mr-4">
                  <Crown className="text-primary" />
                </div>
                <div>
                  <h3 className="font-playfair font-semibold text-lg text-charcoal mb-1">
                    Exclusive Designs
                  </h3>
                  <p className="font-poppins text-gray-600">
                    Your custom piece is uniquely yours, tailored to your specific style preferences.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="bg-primary/10 p-3 rounded-full mr-4">
                  <CalendarCheck className="text-primary" />
                </div>
                <div>
                  <h3 className="font-playfair font-semibold text-lg text-charcoal mb-1">
                    Timely Delivery
                  </h3>
                  <p className="font-poppins text-gray-600">
                    We understand the importance of your occasions and ensure on-time delivery.
                  </p>
                </div>
              </div>
            </div>
            
            <div className="mt-8 grid grid-cols-2 gap-4">
              <img src="https://images.unsplash.com/photo-1573612664822-d7d347da7b80?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" alt="Custom Saree Design" className="w-full h-40 object-cover rounded-lg" />
              <img src="https://images.unsplash.com/photo-1609226933651-e1c1a8896857?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" alt="Custom Lehenga Design" className="w-full h-40 object-cover rounded-lg" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
