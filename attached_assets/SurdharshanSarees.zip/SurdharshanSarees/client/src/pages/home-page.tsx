import Hero from "@/components/Hero";
import FeaturedCategories from "@/components/FeaturedCategories";
import ProductGrid from "@/components/ProductGrid";
import Testimonials from "@/components/Testimonials";
import Newsletter from "@/components/Newsletter";
import { Check } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { Category } from "@shared/schema";
import { Link } from "wouter";

export default function HomePage() {
  const { data: categories } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });
  
  return (
    <>
      <Hero />
      
      <FeaturedCategories />
      
      <ProductGrid 
        title="Featured Products"
        description="Browse through our meticulously crafted pieces, showcasing the finest materials and expert artisanship."
        queryKey="/api/products/featured"
        limit={8}
      />
      
      {/* About Section */}
      <section id="about" className="py-16 px-6 md:px-12 lg:px-24 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-4">
                  <img src="https://images.unsplash.com/photo-1573612664822-d7d347da7b80?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" alt="Craftsmanship" className="w-full h-48 object-cover rounded-lg" />
                  <img src="https://images.unsplash.com/photo-1610030181087-285c5fa57493?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" alt="Traditional Designs" className="w-full h-32 object-cover rounded-lg" />
                </div>
                <div className="space-y-4 pt-6">
                  <img src="https://images.unsplash.com/photo-1609226933651-e1c1a8896857?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" alt="Luxury Fabric" className="w-full h-32 object-cover rounded-lg" />
                  <img src="https://images.unsplash.com/photo-1624398090966-c3d5a2174c84?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" alt="Modern Designs" className="w-full h-48 object-cover rounded-lg" />
                </div>
              </div>
            </div>
            
            <div>
              <h2 className="font-playfair text-3xl md:text-4xl font-bold text-charcoal mb-6">Our Heritage of Excellence</h2>
              <p className="font-poppins text-gray-600 mb-6">
                Surdharshan Designer has been a symbol of luxury and elegance in the Indian fashion landscape for over two decades. 
                Our journey began with a passion for preserving traditional Indian craftsmanship while embracing contemporary aesthetics.
              </p>
              
              <p className="font-poppins text-gray-600 mb-6">
                Each piece in our collection is a testament to the rich cultural heritage of India, meticulously crafted by skilled 
                artisans who have honed their craft over generations. We take pride in sourcing the finest materials and supporting local craftsmen.
              </p>
              
              <div className="space-y-6 mb-8">
                <div className="flex items-start">
                  <div className="bg-primary/10 p-3 rounded-full mr-4">
                    <Check className="text-primary" />
                  </div>
                  <div>
                    <h3 className="font-playfair font-semibold text-lg text-charcoal mb-1">Ethical Sourcing</h3>
                    <p className="font-poppins text-gray-600">We source materials directly from weavers and ensure fair compensation.</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="bg-primary/10 p-3 rounded-full mr-4">
                    <Check className="text-primary" />
                  </div>
                  <div>
                    <h3 className="font-playfair font-semibold text-lg text-charcoal mb-1">Artisan Support</h3>
                    <p className="font-poppins text-gray-600">We collaborate with skilled artisans across India to preserve traditional techniques.</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="bg-primary/10 p-3 rounded-full mr-4">
                    <Check className="text-primary" />
                  </div>
                  <div>
                    <h3 className="font-playfair font-semibold text-lg text-charcoal mb-1">Quality Assurance</h3>
                    <p className="font-poppins text-gray-600">Each piece undergoes rigorous quality checks before reaching our customers.</p>
                  </div>
                </div>
              </div>
              
              <Link href="/contact">
                <a className="inline-flex items-center justify-center py-3 px-8 bg-primary hover:bg-primary/90 text-white font-poppins font-medium rounded-md transition-colors duration-300">
                  Get In Touch
                </a>
              </Link>
            </div>
          </div>
        </div>
      </section>
      
      <Testimonials />
      
      <ProductGrid 
        title="New Arrivals"
        description="Discover our latest additions, carefully curated to reflect the current trends while honoring timeless traditions."
        queryKey="/api/products/new"
        limit={4}
      />
      
      <Newsletter />
    </>
  );
}
