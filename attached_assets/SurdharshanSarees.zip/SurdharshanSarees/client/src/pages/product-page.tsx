import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { Product } from "@shared/schema";
import { useCart } from "@/hooks/use-cart";
import { formatPrice } from "@/lib/utils";
import { RatingDisplay } from "@/components/ui/rating-display";
import { Button } from "@/components/ui/button";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { Loader2, Minus, Plus, ShoppingBag, Heart } from "lucide-react";
import ProductGrid from "@/components/ProductGrid";

export default function ProductPage() {
  const [_, params] = useRoute<{ slug: string }>("/product/:slug");
  const [quantity, setQuantity] = useState(1);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const { addItem } = useCart();
  
  const { data: product, isLoading } = useQuery<Product & { 
    category: { name: string; slug: string }; 
    material: { name: string }; 
    workType: { name: string };
    images?: { id: number; imageUrl: string; isPrimary: boolean }[];
  }>({
    queryKey: [`/api/products/slug/${params?.slug}`],
    enabled: !!params?.slug,
  });
  
  const increaseQuantity = () => {
    setQuantity(prev => prev + 1);
  };
  
  const decreaseQuantity = () => {
    if (quantity > 1) {
      setQuantity(prev => prev - 1);
    }
  };
  
  const handleAddToCart = () => {
    if (product) {
      addItem(product, quantity);
    }
  };
  
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  if (!product) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] px-4">
        <h1 className="font-playfair text-2xl md:text-3xl font-bold text-charcoal mb-4">
          Product Not Found
        </h1>
        <p className="text-gray-600 mb-6 text-center">
          The product you are looking for doesn't exist or has been removed.
        </p>
        <Button asChild>
          <a href="/collections">Return to Collections</a>
        </Button>
      </div>
    );
  }
  
  return (
    <>
      <section className="py-12 px-6 md:px-12 lg:px-24 bg-background">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10 lg:gap-16">
            {/* Product Images */}
            <div className="space-y-4">
              {/* Main Image */}
              <div className="rounded-lg overflow-hidden bg-gray-50 flex items-center justify-center">
                <img 
                  src={product.images?.[currentImageIndex]?.imageUrl || product.imageUrl} 
                  alt={product.name}
                  className="w-full h-[500px] object-contain"
                />
              </div>
              
              {/* Image Thumbnails */}
              {product.images && product.images.length > 1 && (
                <div className="grid grid-cols-5 gap-2">
                  {product.images.map((image, index) => (
                    <div 
                      key={image.id}
                      className={`rounded-md overflow-hidden cursor-pointer border-2 ${index === currentImageIndex ? 'border-primary' : 'border-transparent hover:border-primary/50'}`}
                      onClick={() => setCurrentImageIndex(index)}
                    >
                      <img 
                        src={image.imageUrl} 
                        alt={`${product.name} - View ${index + 1}`} 
                        className="w-full h-20 object-cover"
                      />
                    </div>
                  ))}
                </div>
              )}
            </div>
            
            {/* Product Details */}
            <div>
              <div className="mb-4">
                <span className="text-sm text-gray-500">
                  {product.category?.name || "Uncategorized"}
                </span>
                <h1 className="font-playfair text-3xl md:text-4xl font-bold text-charcoal mt-1">
                  {product.name}
                </h1>
              </div>
              
              <div className="flex items-center mb-4">
                <RatingDisplay rating={parseFloat(product.rating?.toString() || "0")} numReviews={product.numReviews || 0} />
              </div>
              
              <div className="mb-6">
                <h2 className="text-2xl font-bold text-primary">
                  {formatPrice(product.price)}
                </h2>
                {parseFloat(product.discountPercent?.toString() || "0") > 0 && (
                  <div className="flex items-center mt-1">
                    <span className="line-through text-gray-500 mr-2">
                      {formatPrice(parseFloat(product.price?.toString() || "0") * (1 + parseFloat(product.discountPercent?.toString() || "0") / 100))}
                    </span>
                    <span className="bg-emerald text-white text-xs px-2 py-0.5 rounded">
                      {product.discountPercent?.toString() || "0"}% OFF
                    </span>
                  </div>
                )}
              </div>
              
              <div className="bg-gray-50 p-4 rounded-lg mb-6">
                <div className="flex flex-col sm:flex-row sm:items-center mb-3">
                  <span className="font-medium w-32 mb-1 sm:mb-0">Material:</span>
                  <span>{product.material?.name || "Not specified"}</span>
                </div>
                <div className="flex flex-col sm:flex-row sm:items-center mb-3">
                  <span className="font-medium w-32 mb-1 sm:mb-0">Work Type:</span>
                  <span>{product.workType?.name || "Not specified"}</span>
                </div>
                <div className="flex flex-col sm:flex-row sm:items-center">
                  <span className="font-medium w-32 mb-1 sm:mb-0">Availability:</span>
                  <span className={product.stock > 0 ? "text-emerald" : "text-destructive"}>
                    {product.stock > 0 ? (
                      product.stock < 5 ? `Only ${product.stock} left in stock` : "In Stock"
                    ) : "Out of Stock"}
                  </span>
                </div>
              </div>
              
              <div className="mb-6">
                <div className="flex items-center">
                  <span className="font-medium mr-4">Quantity:</span>
                  <div className="flex items-center border border-gray-300 rounded-md">
                    <button
                      className="px-3 py-2 border-r border-gray-300 focus:outline-none"
                      onClick={decreaseQuantity}
                      disabled={quantity <= 1}
                    >
                      <Minus className="h-4 w-4" />
                    </button>
                    <span className="px-4 py-2">{quantity}</span>
                    <button
                      className="px-3 py-2 border-l border-gray-300 focus:outline-none"
                      onClick={increaseQuantity}
                    >
                      <Plus className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4 mb-8">
                <Button 
                  className="px-8 py-6 bg-primary hover:bg-primary/90 text-white flex-1 sm:flex-none"
                  onClick={handleAddToCart}
                  disabled={product.stock <= 0}
                >
                  <ShoppingBag className="mr-2 h-5 w-5" />
                  Add to Cart
                </Button>
                <Button 
                  variant="outline" 
                  className="px-8 py-6 border-primary text-primary hover:bg-background flex-1 sm:flex-none"
                >
                  <Heart className="mr-2 h-5 w-5" />
                  Add to Wishlist
                </Button>
              </div>
              
              <Tabs defaultValue="description" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="description">Description</TabsTrigger>
                  <TabsTrigger value="details">Details</TabsTrigger>
                  <TabsTrigger value="reviews">Reviews</TabsTrigger>
                </TabsList>
                <TabsContent value="description" className="pt-4">
                  <p className="text-gray-600">{product.description}</p>
                </TabsContent>
                <TabsContent value="details" className="pt-4">
                  <ul className="space-y-2 text-gray-600">
                    <li>
                      <strong>Category:</strong> {product.category?.name}
                    </li>
                    <li>
                      <strong>Material:</strong> {product.material?.name}
                    </li>
                    <li>
                      <strong>Work Type:</strong> {product.workType?.name}
                    </li>
                    <li>
                      <strong>SKU:</strong> SURD-{product.id}
                    </li>
                    <li>
                      <strong>Care Instructions:</strong> Dry clean only
                    </li>
                  </ul>
                </TabsContent>
                <TabsContent value="reviews" className="pt-4">
                  <div className="text-center py-4">
                    <h3 className="font-medium text-lg mb-2">Customer Reviews</h3>
                    <div className="flex justify-center mb-2">
                      <RatingDisplay rating={parseFloat(product.rating?.toString() || "0")} />
                    </div>
                    <p className="text-sm text-gray-500 mb-4">
                      Based on {product.numReviews} reviews
                    </p>
                    <Button variant="outline" className="mx-auto">
                      Write a Review
                    </Button>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </div>
      </section>
      
      {/* Similar Products */}
      <ProductGrid 
        title="You Might Also Like"
        queryKey={`/api/products?categoryId=${product.categoryId}&limit=4`}
        limit={4}
      />
    </>
  );
}
