import { db } from "./index";
import * as schema from "@shared/schema";
import { scrypt, randomBytes } from "crypto";
import { promisify } from "util";

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function seed() {
  try {
    console.log("Seeding database...");

    // Seed admin user
    const adminExists = await db.query.users.findFirst({
      where: (users, { eq }) => eq(users.username, "admin")
    });

    if (!adminExists) {
      console.log("Creating admin user...");
      await db.insert(schema.users).values({
        username: "admin",
        password: await hashPassword("admin123"),
        email: "admin@surdharshandesigner.com",
        fullName: "Admin User",
        isAdmin: true
      });
    }

    // Seed categories
    const categories = [
      { name: "Bridal Collection", slug: "bridal-collection", description: "Exquisite bridal pieces for your special day", imageUrl: "https://images.unsplash.com/photo-1573612664822-d7d347da7b80?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" },
      { name: "Designer Sarees", slug: "designer-sarees", description: "Contemporary designs with traditional craftsmanship", imageUrl: "https://images.unsplash.com/photo-1624398090966-c3d5a2174c84?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" },
      { name: "Luxury Lehengas", slug: "luxury-lehengas", description: "Ornate designs for celebrations and special occasions", imageUrl: "https://images.unsplash.com/photo-1609226933651-e1c1a8896857?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" },
      { name: "Festive Wear", slug: "festive-wear", description: "Vibrant and elegant outfits for festive occasions", imageUrl: "https://images.unsplash.com/photo-1610030881448-3afbad2b74c4?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" }
    ];

    for (const category of categories) {
      const existing = await db.query.categories.findFirst({
        where: (categories, { eq }) => eq(categories.slug, category.slug)
      });

      if (!existing) {
        console.log(`Creating category: ${category.name}`);
        await db.insert(schema.categories).values(category);
      }
    }

    // Seed materials
    const materials = [
      { name: "Ghazi Silk", description: "Premium silk fabric with a rich texture and sheen" },
      { name: "Banarasi", description: "Traditional silk fabric from Varanasi with intricate designs" },
      { name: "Bandni", description: "Tie-dyed fabric with distinctive patterns" },
      { name: "Pure Silk", description: "High-quality natural silk fabric" },
      { name: "Georgette", description: "Lightweight, sheer fabric with a crinkled texture" }
    ];

    for (const material of materials) {
      const existing = await db.query.materials.findFirst({
        where: (materials, { eq }) => eq(materials.name, material.name)
      });

      if (!existing) {
        console.log(`Creating material: ${material.name}`);
        await db.insert(schema.materials).values(material);
      }
    }

    // Seed work types
    const workTypes = [
      { name: "Gotta Patti", description: "Traditional embroidery technique using appliqué work with gold or silver ribbons" },
      { name: "Jardoji", description: "Embroidery technique using metallic threads" },
      { name: "Hand Embroidery", description: "Intricate designs created by hand using various stitches" },
      { name: "Zari Work", description: "Embroidery using fine threads made of gold or silver" },
      { name: "Hand Painted", description: "Unique designs painted by hand on fabric" }
    ];

    for (const workType of workTypes) {
      const existing = await db.query.workTypes.findFirst({
        where: (workTypes, { eq }) => eq(workTypes.name, workType.name)
      });

      if (!existing) {
        console.log(`Creating work type: ${workType.name}`);
        await db.insert(schema.workTypes).values(workType);
      }
    }

    // Get category IDs
    const categoryData = await db.query.categories.findMany();
    const materialData = await db.query.materials.findMany();
    const workTypeData = await db.query.workTypes.findMany();

    const categoryMap = new Map(categoryData.map(c => [c.slug, c.id]));
    const materialMap = new Map(materialData.map(m => [m.name, m.id]));
    const workTypeMap = new Map(workTypeData.map(w => [w.name, w.id]));

    // Seed products
    const products = [
      {
        name: "Red Bridal Saree",
        slug: "red-bridal-saree",
        description: "Stunning red bridal saree featuring intricate Gotta Patti work on premium Ghazi Silk. Perfect for the bride who wants to make a statement on her special day.",
        price: 32500,
        imageUrl: "https://images.unsplash.com/photo-1573612664822-d7d347da7b80?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
        categoryId: categoryMap.get("bridal-collection"),
        materialId: materialMap.get("Ghazi Silk"),
        workTypeId: workTypeMap.get("Gotta Patti"),
        stock: 5,
        featured: true,
        rating: 4.5,
        numReviews: 28
      },
      {
        name: "Blue Designer Lehenga",
        slug: "blue-designer-lehenga",
        description: "Exquisite blue designer lehenga with detailed Jardoji work on luxurious Banarasi silk. A perfect choice for weddings and special celebrations.",
        price: 45200,
        imageUrl: "https://images.unsplash.com/photo-1609226933651-e1c1a8896857?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
        categoryId: categoryMap.get("luxury-lehengas"),
        materialId: materialMap.get("Banarasi"),
        workTypeId: workTypeMap.get("Jardoji"),
        stock: 3,
        featured: true,
        rating: 5.0,
        numReviews: 42
      },
      {
        name: "Pink Embellished Saree",
        slug: "pink-embellished-saree",
        description: "Beautiful pink georgette saree with delicate hand embroidery. A versatile addition to your collection that can be worn for various occasions.",
        price: 18900,
        imageUrl: "https://images.unsplash.com/photo-1578148377458-25d11132ecaa?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
        categoryId: categoryMap.get("designer-sarees"),
        materialId: materialMap.get("Georgette"),
        workTypeId: workTypeMap.get("Hand Embroidery"),
        stock: 8,
        isNew: true,
        rating: 4.0,
        numReviews: 16
      },
      {
        name: "Green Embroidered Saree",
        slug: "green-embroidered-saree",
        description: "Elegant green pure silk saree with intricate hand embroidery. The perfect blend of tradition and contemporary design for the modern woman.",
        price: 29800,
        imageUrl: "https://images.unsplash.com/photo-1610030181087-285c5fa57493?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
        categoryId: categoryMap.get("designer-sarees"),
        materialId: materialMap.get("Pure Silk"),
        workTypeId: workTypeMap.get("Hand Embroidery"),
        stock: 4,
        featured: true,
        rating: 4.5,
        numReviews: 35
      },
      {
        name: "Golden Bridal Lehenga",
        slug: "golden-bridal-lehenga",
        description: "Opulent golden bridal lehenga crafted from Ghazi silk with exquisite Zari work. Make a statement on your wedding day with this stunning piece.",
        price: 48500,
        imageUrl: "https://images.unsplash.com/photo-1576995853123-5a10305d93c0?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
        categoryId: categoryMap.get("bridal-collection"),
        materialId: materialMap.get("Ghazi Silk"),
        workTypeId: workTypeMap.get("Zari Work"),
        stock: 2,
        featured: true,
        rating: 4.0,
        numReviews: 19
      },
      {
        name: "Purple Designer Saree",
        slug: "purple-designer-saree",
        description: "Luxurious purple Bandni saree with intricate Gotta Patti work. A unique addition to your wardrobe for special occasions and celebrations.",
        price: 26700,
        imageUrl: "https://images.unsplash.com/photo-1610030881448-3afbad2b74c4?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
        categoryId: categoryMap.get("designer-sarees"),
        materialId: materialMap.get("Bandni"),
        workTypeId: workTypeMap.get("Gotta Patti"),
        stock: 6,
        featured: true,
        rating: 5.0,
        numReviews: 31
      },
      {
        name: "Orange Festive Lehenga",
        slug: "orange-festive-lehenga",
        description: "Vibrant orange Banarasi lehenga with detailed Jardoji work. Perfect for festival celebrations and special occasions.",
        price: 22300,
        imageUrl: "https://images.unsplash.com/photo-1624398090966-c3d5a2174c84?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
        categoryId: categoryMap.get("festive-wear"),
        materialId: materialMap.get("Banarasi"),
        workTypeId: workTypeMap.get("Jardoji"),
        stock: 7,
        isNew: true,
        rating: 3.5,
        numReviews: 12
      },
      {
        name: "Maroon Wedding Saree",
        slug: "maroon-wedding-saree",
        description: "Elegant maroon Pure Silk saree with detailed Zari work. A timeless piece for weddings and special celebrations.",
        price: 36900,
        imageUrl: "https://images.unsplash.com/photo-1617038220319-276d3cfab638?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
        categoryId: categoryMap.get("bridal-collection"),
        materialId: materialMap.get("Pure Silk"),
        workTypeId: workTypeMap.get("Zari Work"),
        stock: 3,
        rating: 4.5,
        numReviews: 23
      },
      {
        name: "Emerald Green Bridal Lehenga",
        slug: "emerald-green-bridal-lehenga",
        description: "Breathtaking emerald green bridal lehenga embellished with intricate Zari work on premium Ghazi silk. The perfect choice for a reception or engagement ceremony.",
        price: 42900,
        imageUrl: "https://images.unsplash.com/photo-1623188959782-01d040aae5d6?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
        categoryId: categoryMap.get("bridal-collection"),
        materialId: materialMap.get("Ghazi Silk"),
        workTypeId: workTypeMap.get("Zari Work"),
        stock: 2,
        featured: true,
        isNew: true,
        rating: 4.8,
        numReviews: 15
      },
      {
        name: "Fuschia Pink Embellished Lehenga",
        slug: "fuschia-pink-embellished-lehenga",
        description: "Stunning fuschia pink lehenga with elaborate hand embroidery on pure silk. A vibrant choice for pre-wedding functions and special celebrations.",
        price: 38500,
        imageUrl: "https://images.unsplash.com/photo-1610972836570-3aa211dc07e3?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
        categoryId: categoryMap.get("luxury-lehengas"),
        materialId: materialMap.get("Pure Silk"),
        workTypeId: workTypeMap.get("Hand Embroidery"),
        stock: 4,
        featured: true,
        rating: 4.6,
        numReviews: 22
      },
      {
        name: "Teal Zari Work Saree",
        slug: "teal-zari-work-saree",
        description: "Elegant teal saree crafted from premium Banarasi silk with intricate Zari work. A sophisticated choice for formal events and celebrations.",
        price: 32800,
        imageUrl: "https://images.unsplash.com/photo-1616416311207-76e8d4efe6a5?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
        categoryId: categoryMap.get("designer-sarees"),
        materialId: materialMap.get("Banarasi"),
        workTypeId: workTypeMap.get("Zari Work"),
        stock: 5,
        isNew: true,
        rating: 4.3,
        numReviews: 18
      },
      {
        name: "Coral Jardoji Lehenga",
        slug: "coral-jardoji-lehenga",
        description: "Vibrant coral lehenga with exquisite Jardoji work on Georgette fabric. Perfect for pre-wedding events and festive celebrations.",
        price: 28900,
        imageUrl: "https://images.unsplash.com/photo-1594387193957-bec3b11b3c3f?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
        categoryId: categoryMap.get("festive-wear"),
        materialId: materialMap.get("Georgette"),
        workTypeId: workTypeMap.get("Jardoji"),
        stock: 6,
        isNew: true,
        rating: 4.2,
        numReviews: 14
      },
      {
        name: "Turquoise Bridal Saree",
        slug: "turquoise-bridal-saree",
        description: "Eye-catching turquoise bridal saree with intricate Gotta Patti work on premium Bandni silk. A unique choice for the modern bride looking for something different.",
        price: 35600,
        imageUrl: "https://images.unsplash.com/photo-1561036771-664f12e3d5cf?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
        categoryId: categoryMap.get("bridal-collection"),
        materialId: materialMap.get("Bandni"),
        workTypeId: workTypeMap.get("Gotta Patti"),
        stock: 3,
        featured: true,
        rating: 4.7,
        numReviews: 26
      },
      {
        name: "Black & Gold Zari Saree",
        slug: "black-gold-zari-saree",
        description: "Sophisticated black saree with stunning gold Zari work on premium Pure Silk. An elegant statement piece for cocktail parties and evening functions.",
        price: 29500,
        imageUrl: "https://images.unsplash.com/photo-1595237479477-c04ce50a3620?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
        categoryId: categoryMap.get("designer-sarees"),
        materialId: materialMap.get("Pure Silk"),
        workTypeId: workTypeMap.get("Zari Work"),
        stock: 4,
        featured: true,
        rating: 4.9,
        numReviews: 32
      },
      {
        name: "Lavender Hand Painted Lehenga",
        slug: "lavender-hand-painted-lehenga",
        description: "Unique lavender lehenga with exquisite hand-painted designs on lightweight Georgette. A creative, artistic choice for pre-wedding functions and special occasions.",
        price: 36800,
        imageUrl: "https://images.unsplash.com/photo-1595436065982-84fa400d8d78?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
        categoryId: categoryMap.get("luxury-lehengas"),
        materialId: materialMap.get("Georgette"),
        workTypeId: workTypeMap.get("Hand Painted"),
        stock: 2,
        isNew: true,
        rating: 4.6,
        numReviews: 17
      }
    ];

    for (const product of products) {
      const existing = await db.query.products.findFirst({
        where: (products, { eq }) => eq(products.slug, product.slug)
      });

      if (!existing) {
        console.log(`Creating product: ${product.name}`);
        // Handle the TypeScript error by explicitly casting product to the correct type
        const [newProduct] = await db.insert(schema.products).values(product as any).returning();
        
        // Add additional product images
        if (newProduct) {
          // Create a few additional images for each product
          const additionalImages = [
            // High-quality lehenga images
            "https://images.unsplash.com/photo-1594387193910-12ac5b3865b4?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
            "https://images.unsplash.com/photo-1609019169097-497ebef39612?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
            "https://images.unsplash.com/photo-1617439433738-3b42714ee089?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
            "https://images.unsplash.com/photo-1623610910718-1f46c88e2793?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
            "https://images.unsplash.com/photo-1607741091173-d3bbca1ed971?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
            
            // High-quality saree images
            "https://images.unsplash.com/photo-1623610910718-1f46c88e2793?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
            "https://images.unsplash.com/photo-1573590330099-d6c7a5afeb68?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
            "https://images.unsplash.com/photo-1610268872530-c90d3dcc9542?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
            "https://images.unsplash.com/photo-1610291467915-026e52cb543b?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
            "https://images.unsplash.com/photo-1572705824045-3dd0c9a47945?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80"
          ];
          
          // Select 2-3 random images for each product
          const numImages = Math.floor(Math.random() * 2) + 2; // 2-3 images
          const shuffled = [...additionalImages].sort(() => 0.5 - Math.random());
          const selectedImages = shuffled.slice(0, numImages);
          
          // Add the product's main image as the primary image
          await db.insert(schema.productImages).values({
            productId: newProduct.id,
            imageUrl: product.imageUrl,
            isPrimary: true
          });
          
          // Add the additional images
          for (const imageUrl of selectedImages) {
            await db.insert(schema.productImages).values({
              productId: newProduct.id,
              imageUrl,
              isPrimary: false
            });
          }
          
          console.log(`Added ${numImages + 1} images for ${product.name}`);
        }
      }
    }

    console.log("Database seeding completed!");
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}

seed();
