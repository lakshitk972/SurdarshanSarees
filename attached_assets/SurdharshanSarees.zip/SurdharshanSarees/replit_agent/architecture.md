# Architecture Overview

## Overview

This repository contains a full-stack e-commerce application for Surdharshan Designer, a business specializing in Indian ethnic wear and designer clothing. The application follows a modern architecture with a React frontend, Node.js/Express backend, and PostgreSQL database using Drizzle ORM.

The application implements features typical of an e-commerce platform including product browsing, cart management, user authentication, payment processing (via Razorpay), and admin functionality for managing products, orders, and customer requests.

## System Architecture

### High-Level Architecture

The application follows a client-server architecture with the following components:

1. **Frontend**: React-based Single Page Application (SPA)
2. **Backend**: Node.js/Express API server
3. **Database**: PostgreSQL accessed via Drizzle ORM
4. **Authentication**: Session-based authentication with Passport.js
5. **Payment Integration**: Razorpay payment gateway

### Directory Structure

```
├── client/                 # Frontend React application
│   ├── src/                # React source code
│   │   ├── components/     # UI components
│   │   ├── hooks/          # Custom React hooks
│   │   ├── lib/            # Utility functions and helpers
│   │   └── pages/          # Page components
├── db/                     # Database related code
├── server/                 # Backend Express API server
├── shared/                 # Shared code between frontend and backend
```

## Key Components

### Frontend

The frontend is built with React and follows a component-based architecture. Key aspects include:

1. **UI Framework**: The application uses the Shadcn UI component system built on Radix UI primitives with Tailwind CSS for styling.

2. **Routing**: The application uses wouter for client-side routing.

3. **State Management**:
   - React Query for server state management
   - React Context for global state like authentication and shopping cart

4. **Key Custom Hooks**:
   - `useAuth`: Manages user authentication state
   - `useCart`: Handles shopping cart functionality
   - `useToast`: Provides notification functionality

5. **Frontend Structure**:
   - Pages are organized under `client/src/pages`
   - Admin-specific pages are under `client/src/pages/admin`
   - Reusable components are in `client/src/components`

### Backend

The backend is built with Express.js and provides RESTful API endpoints for the frontend. Key aspects include:

1. **API Structure**: 
   - RESTful endpoints under `/api` prefix
   - Controllers organized by domain (products, users, orders, etc.)

2. **Authentication**:
   - Passport.js for authentication
   - Express-session for session management 
   - PostgreSQL session store

3. **Payment Integration**:
   - Razorpay for payment processing
   - Server-side verification of payment signatures

4. **Data Access**:
   - Drizzle ORM for database interactions
   - Repository pattern implemented in `server/storage.ts`

### Database

The application uses PostgreSQL with Drizzle ORM. Schema is defined in `shared/schema.ts`.

Key entities in the database include:

1. **users**: Store user accounts and credentials
2. **categories**: Product categories 
3. **products**: Product information
4. **orders**: Customer orders
5. **customRequests**: Custom order requests from customers

Relationships between entities are managed using Drizzle's relations API.

## Data Flow

### Authentication Flow

1. User submits login credentials via frontend
2. Backend authenticates using Passport.js
3. On successful authentication, user session is established
4. Frontend fetches current user data from `/api/user` endpoint
5. Protected routes check for authenticated user

### Shopping Flow

1. Products are loaded from backend API
2. User adds products to cart (managed in browser local storage)
3. On checkout, cart items are sent to backend
4. Payment is initiated via Razorpay
5. On successful payment, order is created in database

### Admin Flow

1. Admin users are authenticated with the same flow as regular users
2. Admin-specific routes check for admin status
3. Admin can manage products, categories, orders and custom requests via dashboards

## External Dependencies

### Frontend Dependencies

- **React**: Core UI library
- **Tailwind CSS**: Utility-first CSS framework
- **Shadcn/Radix UI**: Component library
- **Tanstack Query**: Data fetching and caching
- **Wouter**: Routing library
- **Zod**: Schema validation
- **Lucide React**: Icon library

### Backend Dependencies

- **Express**: Web server framework
- **Passport**: Authentication middleware
- **Drizzle ORM**: Database ORM
- **Neon Serverless**: PostgreSQL client for Neon database
- **Razorpay SDK**: Payment gateway integration

## Deployment Strategy

The application is configured for deployment on Replit, with the following setup:

1. **Build Process**:
   - Frontend is built using Vite (`npm run build`)
   - Backend is bundled using esbuild
   - Static assets are served from `dist/public`

2. **Runtime Configuration**:
   - Environment variables for database connection, session secrets, and API keys
   - Production mode determined by `NODE_ENV`

3. **Database Migrations**:
   - Managed with Drizzle Kit
   - Migration scripts in package.json for schema updates

4. **Runtime**:
   - Development: Vite dev server with API proxying to Express
   - Production: Express serves both API and static assets

The application could be adapted for deployment to other platforms with minimal changes to the configuration files.