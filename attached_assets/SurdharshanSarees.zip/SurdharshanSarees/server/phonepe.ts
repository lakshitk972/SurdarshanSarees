import axios from 'axios';
import { Request, Response } from 'express';
import crypto from 'crypto';
import { v4 as uuidv4 } from 'uuid';

// PhonePe Test Configuration
const PHONEPE_HOST = 'https://api-preprod.phonepe.com/apis/pg-sandbox';
const MERCHANT_ID = 'PGTESTPAYUAT';
const SALT_KEY = '099eb0cd-02cf-4e2a-8aca-3e6c6aff0399';
const SALT_INDEX = 1;

// Generate SHA256 checksum
function generateChecksum(payload: string, saltKey: string): string {
  return crypto
    .createHmac('sha256', saltKey)
    .update(payload + '/pg/v1/pay' + saltKey) // Append the API endpoint
    .digest('hex') + '###' + SALT_INDEX;
}

// Create a new PhonePe order
export async function createPhonePeOrder(req: Request, res: Response) {
  try {
    const { amount, customerName, customerEmail, customerPhone } = req.body;
    
    if (!amount || isNaN(parseFloat(amount)) || parseFloat(amount) <= 0) {
      return res.status(400).json({
        success: false,
        message: 'Invalid amount. Amount must be a positive number.'
      });
    }
    
    // Generate a unique transaction ID
    const merchantTransactionId = 'MT' + Date.now();
    
    // Create the payload
    const payload = {
      merchantId: MERCHANT_ID,
      merchantTransactionId: merchantTransactionId,
      merchantUserId: 'MUID' + Date.now(),
      amount: Math.round(parseFloat(amount) * 100), // Amount in paise
      redirectUrl: `${req.protocol}://${req.get('host')}/api/phonepe/callback`,
      redirectMode: 'REDIRECT',
      callbackUrl: `${req.protocol}://${req.get('host')}/api/phonepe/callback`,
      mobileNumber: customerPhone || '9999999999',
      paymentInstrument: {
        type: 'PAY_PAGE'
      }
    };
    
    // Convert payload to base64
    const base64Payload = Buffer.from(JSON.stringify(payload)).toString('base64');
    
    // Generate checksum
    const checksum = generateChecksum(base64Payload, SALT_KEY);
    
    // Make API request to PhonePe
    const response = await axios.post(
      `${PHONEPE_HOST}/pg/v1/pay`,
      {
        request: base64Payload
      },
      {
        headers: {
          'Content-Type': 'application/json',
          'X-VERIFY': checksum
        }
      }
    );
    
    // Send response back to client
    res.json({
      success: true,
      data: response.data,
      merchantTransactionId: merchantTransactionId
    });
  } catch (error) {
    console.error('Error creating PhonePe order:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error creating payment order',
      error: error instanceof Error ? error.message : 'Unknown error'
    });
  }
}

// Verify PhonePe payment status
export async function verifyPhonePePayment(req: Request, res: Response) {
  try {
    const { merchantTransactionId } = req.params;
    
    if (!merchantTransactionId) {
      return res.status(400).json({ 
        success: false, 
        message: 'Transaction ID is required' 
      });
    }
    
    // Generate checksum for status check
    const payload = `/pg/v1/status/${MERCHANT_ID}/${merchantTransactionId}`;
    const checksum = crypto
      .createHmac('sha256', SALT_KEY)
      .update(payload + SALT_KEY)
      .digest('hex') + '###' + SALT_INDEX;
    
    // Make API request to check status
    const response = await axios.get(
      `${PHONEPE_HOST}${payload}`,
      {
        headers: {
          'Content-Type': 'application/json',
          'X-VERIFY': checksum,
          'X-MERCHANT-ID': MERCHANT_ID
        }
      }
    );
    
    // Check if payment was successful
    const paymentData = response.data;
    const isSuccess = 
      paymentData.success && 
      paymentData.code === 'PAYMENT_SUCCESS' && 
      paymentData.data.responseCode === 'SUCCESS';
    
    res.json({
      success: true,
      isPaymentSuccessful: isSuccess,
      data: paymentData
    });
  } catch (error) {
    console.error('Error verifying PhonePe payment:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error verifying payment',
      error: error instanceof Error ? error.message : 'Unknown error'
    });
  }
}

// Handle PhonePe callback
export async function handlePhonePeCallback(req: Request, res: Response) {
  try {
    const { merchantTransactionId, transactionId, status } = req.body;
    
    console.log('PhonePe Callback Data:', req.body);
    
    // Forward the user to appropriate page based on payment status
    if (status === 'SUCCESS') {
      // In a real app, you would update your database here
      res.redirect(`/checkout/success?txnId=${transactionId}`);
    } else {
      res.redirect(`/checkout/failure?txnId=${transactionId}&reason=${status}`);
    }
  } catch (error) {
    console.error('Error processing PhonePe callback:', error);
    res.redirect('/checkout/failure?reason=server_error');
  }
}
