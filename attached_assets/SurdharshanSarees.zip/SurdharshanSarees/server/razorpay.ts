import Razorpay from 'razorpay';
import { Request, Response } from 'express';
import crypto from 'crypto';

// Initialize Razorpay with environment variables
const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID || 'rzp_test_a1b2c3d4e5f6', // Default to test key if not provided
  key_secret: process.env.RAZORPAY_KEY_SECRET || 'a1b2c3d4e5f6g7h8i9j0', // Default to test secret if not provided
});

// Create a new order
export async function createRazorpayOrder(req: Request, res: Response) {
  try {
    const { amount, currency = 'INR', receipt = 'order_receipt_' + Date.now() } = req.body;
    
    // Amount should be in paise (smallest currency unit), so multiply by 100
    const options = {
      amount: Math.round(parseFloat(amount) * 100),
      currency,
      receipt,
      payment_capture: 1
    };
    
    const order = await razorpay.orders.create(options);
    res.json({
      id: order.id,
      amount: order.amount,
      currency: order.currency,
      key: process.env.RAZORPAY_KEY_ID || 'rzp_test_a1b2c3d4e5f6'
    });
  } catch (error) {
    console.error('Error creating Razorpay order:', error);
    res.status(500).json({ error: 'Error creating payment order' });
  }
}

// Verify payment signature
export async function verifyRazorpayPayment(req: Request, res: Response) {
  try {
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body;
    
    // Create a signature with your key_secret to compare with the received signature
    const expectedSignature = crypto
      .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET || 'a1b2c3d4e5f6g7h8i9j0')
      .update(`${razorpay_order_id}|${razorpay_payment_id}`)
      .digest('hex');
    
    // Compare signatures
    const isValid = expectedSignature === razorpay_signature;
    
    if (isValid) {
      res.json({ verified: true, payment_id: razorpay_payment_id });
    } else {
      res.status(400).json({ verified: false, error: 'Invalid signature' });
    }
  } catch (error) {
    console.error('Error verifying Razorpay payment:', error);
    res.status(500).json({ error: 'Error verifying payment' });
  }
}

// Get Razorpay key details for client-side (public key only)
export async function getRazorpayKey(req: Request, res: Response) {
  try {
    res.json({ key: process.env.RAZORPAY_KEY_ID || 'rzp_test_a1b2c3d4e5f6' });
  } catch (error) {
    console.error('Error providing Razorpay key:', error);
    res.status(500).json({ error: 'Error providing key' });
  }
}
