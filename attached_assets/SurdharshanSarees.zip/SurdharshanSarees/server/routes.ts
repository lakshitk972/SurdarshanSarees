import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { insertProductSchema, insertCategorySchema, insertMaterialSchema, insertWorkTypeSchema, insertCustomRequestSchema, insertOrderSchema, insertOrderItemSchema, insertProductImageSchema } from "@shared/schema";
import { z } from "zod";
import { createPhonePeOrder, verifyPhonePePayment, handlePhonePeCallback } from "./phonepe";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes
  setupAuth(app);
  
  // API prefix
  const apiPrefix = '/api';
  
  // PhonePe API
  app.post(`${apiPrefix}/phonepe/create-order`, createPhonePeOrder);
  app.post(`${apiPrefix}/phonepe/verify-payment/:merchantTransactionId`, verifyPhonePePayment);
  app.post(`${apiPrefix}/phonepe/callback`, handlePhonePeCallback);
  
  // Categories API
  app.get(`${apiPrefix}/categories`, async (req, res) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      console.error("Error fetching categories:", error);
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });
  
  app.get(`${apiPrefix}/categories/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid category ID" });
      }
      
      const category = await storage.getCategoryById(id);
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      
      res.json(category);
    } catch (error) {
      console.error("Error fetching category:", error);
      res.status(500).json({ message: "Failed to fetch category" });
    }
  });
  
  app.post(`${apiPrefix}/admin/categories`, async (req, res) => {
    try {
      const validatedData = insertCategorySchema.parse(req.body);
      const category = await storage.createCategory(validatedData);
      res.status(201).json(category);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error creating category:", error);
      res.status(500).json({ message: "Failed to create category" });
    }
  });
  
  // Materials API
  app.get(`${apiPrefix}/materials`, async (req, res) => {
    try {
      const materials = await storage.getMaterials();
      res.json(materials);
    } catch (error) {
      console.error("Error fetching materials:", error);
      res.status(500).json({ message: "Failed to fetch materials" });
    }
  });
  
  app.post(`${apiPrefix}/admin/materials`, async (req, res) => {
    try {
      const validatedData = insertMaterialSchema.parse(req.body);
      const material = await storage.createMaterial(validatedData);
      res.status(201).json(material);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error creating material:", error);
      res.status(500).json({ message: "Failed to create material" });
    }
  });
  
  // Work Types API
  app.get(`${apiPrefix}/work-types`, async (req, res) => {
    try {
      const workTypes = await storage.getWorkTypes();
      res.json(workTypes);
    } catch (error) {
      console.error("Error fetching work types:", error);
      res.status(500).json({ message: "Failed to fetch work types" });
    }
  });
  
  app.post(`${apiPrefix}/admin/work-types`, async (req, res) => {
    try {
      const validatedData = insertWorkTypeSchema.parse(req.body);
      const workType = await storage.createWorkType(validatedData);
      res.status(201).json(workType);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error creating work type:", error);
      res.status(500).json({ message: "Failed to create work type" });
    }
  });
  
  // Products API
  app.get(`${apiPrefix}/products`, async (req, res) => {
    try {
      const { 
        page, limit, categoryId, materialId, workTypeId, 
        minPrice, maxPrice, search, sort, featured, isNew 
      } = req.query;
      
      const result = await storage.getProducts({
        page: page ? parseInt(page as string) : undefined,
        limit: limit ? parseInt(limit as string) : undefined,
        categoryId: categoryId ? parseInt(categoryId as string) : undefined,
        materialId: materialId ? parseInt(materialId as string) : undefined,
        workTypeId: workTypeId ? parseInt(workTypeId as string) : undefined,
        minPrice: minPrice ? parseFloat(minPrice as string) : undefined,
        maxPrice: maxPrice ? parseFloat(maxPrice as string) : undefined,
        search: search as string | undefined,
        sort: sort as 'price_asc' | 'price_desc' | 'newest' | 'rating' | undefined,
        featured: featured === 'true' ? true : featured === 'false' ? false : undefined,
        isNew: isNew === 'true' ? true : isNew === 'false' ? false : undefined
      });
      
      res.json(result);
    } catch (error) {
      console.error("Error fetching products:", error);
      res.status(500).json({ message: "Failed to fetch products" });
    }
  });
  
  app.get(`${apiPrefix}/products/featured`, async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const products = await storage.getFeaturedProducts(limit);
      res.json(products);
    } catch (error) {
      console.error("Error fetching featured products:", error);
      res.status(500).json({ message: "Failed to fetch featured products" });
    }
  });
  
  app.get(`${apiPrefix}/products/new`, async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const products = await storage.getNewProducts(limit);
      res.json(products);
    } catch (error) {
      console.error("Error fetching new products:", error);
      res.status(500).json({ message: "Failed to fetch new products" });
    }
  });
  
  app.get(`${apiPrefix}/products/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid product ID" });
      }
      
      const product = await storage.getProductById(id);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      // Get product images
      const images = await storage.getProductImagesByProductId(product.id);
      
      // Get related data
      const category = await storage.getCategoryById(product.categoryId);
      const material = await storage.getMaterialById(product.materialId);
      const workType = await storage.getWorkTypeById(product.workTypeId);
      
      res.json({
        ...product,
        images,
        category,
        material,
        workType
      });
    } catch (error) {
      console.error("Error fetching product:", error);
      res.status(500).json({ message: "Failed to fetch product" });
    }
  });
  
  app.get(`${apiPrefix}/products/slug/:slug`, async (req, res) => {
    try {
      const slug = req.params.slug;
      const product = await storage.getProductBySlug(slug);
      
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      // Get product images
      const images = await storage.getProductImagesByProductId(product.id);
      
      // Get related data
      const category = await storage.getCategoryById(product.categoryId);
      const material = await storage.getMaterialById(product.materialId);
      const workType = await storage.getWorkTypeById(product.workTypeId);
      
      res.json({
        ...product,
        images,
        category,
        material,
        workType
      });
    } catch (error) {
      console.error("Error fetching product by slug:", error);
      res.status(500).json({ message: "Failed to fetch product" });
    }
  });
  
  app.post(`${apiPrefix}/admin/products`, async (req, res) => {
    try {
      const validatedData = insertProductSchema.parse(req.body);
      const product = await storage.createProduct(validatedData);
      res.status(201).json(product);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error creating product:", error);
      res.status(500).json({ message: "Failed to create product" });
    }
  });
  
  app.put(`${apiPrefix}/admin/products/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid product ID" });
      }
      
      const validatedData = insertProductSchema.partial().parse(req.body);
      const product = await storage.updateProduct(id, validatedData);
      res.json(product);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error updating product:", error);
      res.status(500).json({ message: "Failed to update product" });
    }
  });
  
  app.delete(`${apiPrefix}/admin/products/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid product ID" });
      }
      
      await storage.deleteProduct(id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting product:", error);
      res.status(500).json({ message: "Failed to delete product" });
    }
  });
  
  // Product Images API
  app.post(`${apiPrefix}/admin/product-images`, async (req, res) => {
    try {
      const validatedData = insertProductImageSchema.parse(req.body);
      const productImage = await storage.createProductImage(validatedData);
      res.status(201).json(productImage);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error creating product image:", error);
      res.status(500).json({ message: "Failed to create product image" });
    }
  });
  
  app.delete(`${apiPrefix}/admin/product-images/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid product image ID" });
      }
      
      await storage.deleteProductImage(id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting product image:", error);
      res.status(500).json({ message: "Failed to delete product image" });
    }
  });
  
  // Custom Requests API
  app.post(`${apiPrefix}/custom-requests`, async (req, res) => {
    try {
      const validatedData = insertCustomRequestSchema.parse(req.body);
      const userId = req.isAuthenticated() ? req.user.id : undefined;
      const customRequest = await storage.createCustomRequest(validatedData, userId);
      res.status(201).json(customRequest);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error creating custom request:", error);
      res.status(500).json({ message: "Failed to create custom request" });
    }
  });
  
  app.get(`${apiPrefix}/custom-requests`, async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "You must be logged in" });
      }
      
      const customRequests = await storage.getCustomRequestsByUserId(req.user.id);
      res.json(customRequests);
    } catch (error) {
      console.error("Error fetching custom requests:", error);
      res.status(500).json({ message: "Failed to fetch custom requests" });
    }
  });
  
  app.get(`${apiPrefix}/admin/custom-requests`, async (req, res) => {
    try {
      const { page, limit, status } = req.query;
      
      const result = await storage.getCustomRequests({
        page: page ? parseInt(page as string) : undefined,
        limit: limit ? parseInt(limit as string) : undefined,
        status: status as string | undefined
      });
      
      res.json(result);
    } catch (error) {
      console.error("Error fetching admin custom requests:", error);
      res.status(500).json({ message: "Failed to fetch custom requests" });
    }
  });
  
  app.put(`${apiPrefix}/admin/custom-requests/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid custom request ID" });
      }
      
      const { status, adminNotes } = req.body;
      if (!status) {
        return res.status(400).json({ message: "Status is required" });
      }
      
      const customRequest = await storage.updateCustomRequestStatus(id, status, adminNotes);
      res.json(customRequest);
    } catch (error) {
      console.error("Error updating custom request:", error);
      res.status(500).json({ message: "Failed to update custom request" });
    }
  });
  
  // Orders API
  app.post(`${apiPrefix}/orders`, async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "You must be logged in" });
      }
      
      const validatedData = insertOrderSchema.parse({
        ...req.body,
        userId: req.user.id
      });
      
      const order = await storage.createOrder(validatedData);
      
      // Process order items
      if (req.body.orderItems && Array.isArray(req.body.orderItems)) {
        for (const item of req.body.orderItems) {
          await storage.createOrderItem({
            orderId: order.id,
            productId: item.productId,
            quantity: item.quantity,
            price: item.price
          });
        }
      }
      
      res.status(201).json(order);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error creating order:", error);
      res.status(500).json({ message: "Failed to create order" });
    }
  });
  
  app.get(`${apiPrefix}/orders`, async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "You must be logged in" });
      }
      
      const orders = await storage.getOrdersByUserId(req.user.id);
      res.json(orders);
    } catch (error) {
      console.error("Error fetching orders:", error);
      res.status(500).json({ message: "Failed to fetch orders" });
    }
  });
  
  app.get(`${apiPrefix}/orders/:id`, async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "You must be logged in" });
      }
      
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid order ID" });
      }
      
      const order = await storage.getOrderById(id);
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      
      // Check if the order belongs to the authenticated user or if the user is an admin
      if (order.userId !== req.user.id && !req.user.isAdmin) {
        return res.status(403).json({ message: "You are not authorized to view this order" });
      }
      
      // Get order items
      const orderItems = await storage.getOrderItemsByOrderId(order.id);
      
      res.json({
        ...order,
        orderItems
      });
    } catch (error) {
      console.error("Error fetching order:", error);
      res.status(500).json({ message: "Failed to fetch order" });
    }
  });
  
  app.get(`${apiPrefix}/admin/orders`, async (req, res) => {
    try {
      const { page, limit, status } = req.query;
      
      const result = await storage.getOrders({
        page: page ? parseInt(page as string) : undefined,
        limit: limit ? parseInt(limit as string) : undefined,
        status: status as string | undefined
      });
      
      res.json(result);
    } catch (error) {
      console.error("Error fetching admin orders:", error);
      res.status(500).json({ message: "Failed to fetch orders" });
    }
  });
  
  app.put(`${apiPrefix}/admin/orders/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid order ID" });
      }
      
      const { status } = req.body;
      if (!status) {
        return res.status(400).json({ message: "Status is required" });
      }
      
      const order = await storage.updateOrderStatus(id, status);
      res.json(order);
    } catch (error) {
      console.error("Error updating order:", error);
      res.status(500).json({ message: "Failed to update order" });
    }
  });
  
  const httpServer = createServer(app);
  return httpServer;
}
