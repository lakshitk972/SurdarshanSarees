import { Pool } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import session from "express-session";
import connectPg from "connect-pg-simple";
import * as schema from "@shared/schema";
import { eq, and, desc, asc, like, or, sql, between, isNull, not } from "drizzle-orm";
import { db, pool } from "@db";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // User related methods
  getUserById: (id: number) => Promise<schema.User>;
  getUserByUsername: (username: string) => Promise<schema.User | undefined>;
  getUserByEmail: (email: string) => Promise<schema.User | undefined>;
  createUser: (user: schema.InsertUser) => Promise<schema.User>;
  
  // Product related methods
  getProducts: (params?: ProductQueryParams) => Promise<{ products: schema.Product[], count: number }>;
  getProductById: (id: number) => Promise<schema.Product | undefined>;
  getProductBySlug: (slug: string) => Promise<schema.Product | undefined>;
  getFeaturedProducts: (limit?: number) => Promise<schema.Product[]>;
  getNewProducts: (limit?: number) => Promise<schema.Product[]>;
  createProduct: (product: schema.InsertProduct) => Promise<schema.Product>;
  updateProduct: (id: number, product: Partial<schema.InsertProduct>) => Promise<schema.Product>;
  deleteProduct: (id: number) => Promise<void>;
  
  // Category related methods
  getCategories: () => Promise<schema.Category[]>;
  getCategoryById: (id: number) => Promise<schema.Category | undefined>;
  getCategoryBySlug: (slug: string) => Promise<schema.Category | undefined>;
  createCategory: (category: schema.InsertCategory) => Promise<schema.Category>;
  
  // Material related methods
  getMaterials: () => Promise<schema.Material[]>;
  getMaterialById: (id: number) => Promise<schema.Material | undefined>;
  createMaterial: (material: schema.InsertMaterial) => Promise<schema.Material>;
  
  // WorkType related methods
  getWorkTypes: () => Promise<schema.WorkType[]>;
  getWorkTypeById: (id: number) => Promise<schema.WorkType | undefined>;
  createWorkType: (workType: schema.InsertWorkType) => Promise<schema.WorkType>;
  
  // Order related methods
  createOrder: (order: schema.InsertOrder) => Promise<schema.Order>;
  getOrdersByUserId: (userId: number) => Promise<schema.Order[]>;
  getOrderById: (id: number) => Promise<schema.Order | undefined>;
  updateOrderStatus: (id: number, status: string) => Promise<schema.Order>;
  getOrders: (params?: OrderQueryParams) => Promise<{ orders: schema.Order[], count: number }>;
  
  // OrderItem related methods
  createOrderItem: (orderItem: schema.InsertOrderItem) => Promise<schema.OrderItem>;
  getOrderItemsByOrderId: (orderId: number) => Promise<schema.OrderItem[]>;
  
  // CustomRequest related methods
  createCustomRequest: (customRequest: schema.InsertCustomRequest, userId?: number) => Promise<schema.CustomRequest>;
  getCustomRequestById: (id: number) => Promise<schema.CustomRequest | undefined>;
  getCustomRequestsByUserId: (userId: number) => Promise<schema.CustomRequest[]>;
  updateCustomRequestStatus: (id: number, status: string, adminNotes?: string) => Promise<schema.CustomRequest>;
  getCustomRequests: (params?: CustomRequestQueryParams) => Promise<{ requests: schema.CustomRequest[], count: number }>;
  
  // ProductImage related methods
  createProductImage: (productImage: schema.InsertProductImage) => Promise<schema.ProductImage>;
  getProductImagesByProductId: (productId: number) => Promise<schema.ProductImage[]>;
  deleteProductImage: (id: number) => Promise<void>;
  
  // Session store
  sessionStore: session.SessionStore;
}

export type ProductQueryParams = {
  page?: number;
  limit?: number;
  categoryId?: number;
  materialId?: number;
  workTypeId?: number;
  minPrice?: number;
  maxPrice?: number;
  search?: string;
  sort?: 'price_asc' | 'price_desc' | 'newest' | 'rating';
  featured?: boolean;
  isNew?: boolean;
};

export type OrderQueryParams = {
  page?: number;
  limit?: number;
  status?: string;
  userId?: number;
};

export type CustomRequestQueryParams = {
  page?: number;
  limit?: number;
  status?: string;
  userId?: number;
};

export class DatabaseStorage implements IStorage {
  sessionStore: session.SessionStore;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool,
      tableName: 'sessions',
      createTableIfMissing: true
    });
  }

  // User related methods
  async getUserById(id: number): Promise<schema.User> {
    const [user] = await db.select().from(schema.users).where(eq(schema.users.id, id));
    
    if (!user) {
      throw new Error(`User with id ${id} not found`);
    }
    
    return user;
  }

  async getUserByUsername(username: string): Promise<schema.User | undefined> {
    const [user] = await db.select().from(schema.users).where(eq(schema.users.username, username));
    return user;
  }

  async getUserByEmail(email: string): Promise<schema.User | undefined> {
    const [user] = await db.select().from(schema.users).where(eq(schema.users.email, email));
    return user;
  }

  async createUser(user: schema.InsertUser): Promise<schema.User> {
    const [newUser] = await db.insert(schema.users).values(user).returning();
    return newUser;
  }

  // Product related methods
  async getProducts(params: ProductQueryParams = {}): Promise<{ products: schema.Product[], count: number }> {
    const {
      page = 1,
      limit = 10,
      categoryId,
      materialId,
      workTypeId,
      minPrice,
      maxPrice,
      search,
      sort,
      featured,
      isNew
    } = params;

    const offset = (page - 1) * limit;
    
    let query = db.select().from(schema.products);
    let countQuery = db.select({ count: sql<number>`count(*)` }).from(schema.products);
    
    // Apply filters
    const conditions = [];
    
    if (categoryId) {
      conditions.push(eq(schema.products.categoryId, categoryId));
    }
    
    if (materialId) {
      conditions.push(eq(schema.products.materialId, materialId));
    }
    
    if (workTypeId) {
      conditions.push(eq(schema.products.workTypeId, workTypeId));
    }
    
    if (minPrice !== undefined && maxPrice !== undefined) {
      conditions.push(between(schema.products.price, minPrice, maxPrice));
    } else if (minPrice !== undefined) {
      conditions.push(sql`${schema.products.price} >= ${minPrice}`);
    } else if (maxPrice !== undefined) {
      conditions.push(sql`${schema.products.price} <= ${maxPrice}`);
    }
    
    if (search) {
      conditions.push(
        or(
          like(schema.products.name, `%${search}%`),
          like(schema.products.description, `%${search}%`)
        )
      );
    }
    
    if (featured !== undefined) {
      conditions.push(eq(schema.products.featured, featured));
    }
    
    if (isNew !== undefined) {
      conditions.push(eq(schema.products.isNew, isNew));
    }
    
    if (conditions.length > 0) {
      const whereCondition = conditions.reduce((acc, condition) => and(acc, condition));
      query = query.where(whereCondition);
      countQuery = countQuery.where(whereCondition);
    }
    
    // Apply sorting
    if (sort) {
      switch (sort) {
        case 'price_asc':
          query = query.orderBy(asc(schema.products.price));
          break;
        case 'price_desc':
          query = query.orderBy(desc(schema.products.price));
          break;
        case 'newest':
          query = query.orderBy(desc(schema.products.createdAt));
          break;
        case 'rating':
          query = query.orderBy(desc(schema.products.rating));
          break;
        default:
          query = query.orderBy(desc(schema.products.createdAt));
      }
    } else {
      query = query.orderBy(desc(schema.products.createdAt));
    }
    
    // Apply pagination
    query = query.limit(limit).offset(offset);
    
    const [countResult] = await countQuery;
    const products = await query;
    
    return {
      products,
      count: countResult?.count || 0
    };
  }

  async getProductById(id: number): Promise<schema.Product | undefined> {
    const [product] = await db.select().from(schema.products).where(eq(schema.products.id, id));
    return product;
  }

  async getProductBySlug(slug: string): Promise<schema.Product | undefined> {
    const [product] = await db.select().from(schema.products).where(eq(schema.products.slug, slug));
    return product;
  }

  async getFeaturedProducts(limit: number = 8): Promise<schema.Product[]> {
    return db
      .select()
      .from(schema.products)
      .where(eq(schema.products.featured, true))
      .limit(limit)
      .orderBy(desc(schema.products.createdAt));
  }

  async getNewProducts(limit: number = 8): Promise<schema.Product[]> {
    return db
      .select()
      .from(schema.products)
      .where(eq(schema.products.isNew, true))
      .limit(limit)
      .orderBy(desc(schema.products.createdAt));
  }

  async createProduct(product: schema.InsertProduct): Promise<schema.Product> {
    const [newProduct] = await db.insert(schema.products).values(product).returning();
    return newProduct;
  }

  async updateProduct(id: number, product: Partial<schema.InsertProduct>): Promise<schema.Product> {
    const [updatedProduct] = await db
      .update(schema.products)
      .set({ ...product, updatedAt: new Date() })
      .where(eq(schema.products.id, id))
      .returning();
    
    if (!updatedProduct) {
      throw new Error(`Product with id ${id} not found`);
    }
    
    return updatedProduct;
  }

  async deleteProduct(id: number): Promise<void> {
    await db.delete(schema.products).where(eq(schema.products.id, id));
  }

  // Category related methods
  async getCategories(): Promise<schema.Category[]> {
    return db.select().from(schema.categories).orderBy(asc(schema.categories.name));
  }

  async getCategoryById(id: number): Promise<schema.Category | undefined> {
    const [category] = await db.select().from(schema.categories).where(eq(schema.categories.id, id));
    return category;
  }

  async getCategoryBySlug(slug: string): Promise<schema.Category | undefined> {
    const [category] = await db.select().from(schema.categories).where(eq(schema.categories.slug, slug));
    return category;
  }

  async createCategory(category: schema.InsertCategory): Promise<schema.Category> {
    const [newCategory] = await db.insert(schema.categories).values(category).returning();
    return newCategory;
  }

  // Material related methods
  async getMaterials(): Promise<schema.Material[]> {
    return db.select().from(schema.materials).orderBy(asc(schema.materials.name));
  }

  async getMaterialById(id: number): Promise<schema.Material | undefined> {
    const [material] = await db.select().from(schema.materials).where(eq(schema.materials.id, id));
    return material;
  }

  async createMaterial(material: schema.InsertMaterial): Promise<schema.Material> {
    const [newMaterial] = await db.insert(schema.materials).values(material).returning();
    return newMaterial;
  }

  // WorkType related methods
  async getWorkTypes(): Promise<schema.WorkType[]> {
    return db.select().from(schema.workTypes).orderBy(asc(schema.workTypes.name));
  }

  async getWorkTypeById(id: number): Promise<schema.WorkType | undefined> {
    const [workType] = await db.select().from(schema.workTypes).where(eq(schema.workTypes.id, id));
    return workType;
  }

  async createWorkType(workType: schema.InsertWorkType): Promise<schema.WorkType> {
    const [newWorkType] = await db.insert(schema.workTypes).values(workType).returning();
    return newWorkType;
  }

  // Order related methods
  async createOrder(order: schema.InsertOrder): Promise<schema.Order> {
    const [newOrder] = await db.insert(schema.orders).values(order).returning();
    return newOrder;
  }

  async getOrdersByUserId(userId: number): Promise<schema.Order[]> {
    return db
      .select()
      .from(schema.orders)
      .where(eq(schema.orders.userId, userId))
      .orderBy(desc(schema.orders.createdAt));
  }

  async getOrderById(id: number): Promise<schema.Order | undefined> {
    const [order] = await db.select().from(schema.orders).where(eq(schema.orders.id, id));
    return order;
  }

  async updateOrderStatus(id: number, status: string): Promise<schema.Order> {
    const [updatedOrder] = await db
      .update(schema.orders)
      .set({ 
        status, 
        updatedAt: new Date(),
        isPaid: status === 'paid' ? true : undefined,
        paidAt: status === 'paid' ? new Date() : undefined,
        isDelivered: status === 'delivered' ? true : undefined,
        deliveredAt: status === 'delivered' ? new Date() : undefined
      })
      .where(eq(schema.orders.id, id))
      .returning();
    
    if (!updatedOrder) {
      throw new Error(`Order with id ${id} not found`);
    }
    
    return updatedOrder;
  }

  async getOrders(params: OrderQueryParams = {}): Promise<{ orders: schema.Order[], count: number }> {
    const { page = 1, limit = 10, status, userId } = params;
    const offset = (page - 1) * limit;
    
    let query = db.select().from(schema.orders);
    let countQuery = db.select({ count: sql<number>`count(*)` }).from(schema.orders);
    
    // Apply filters
    const conditions = [];
    
    if (status) {
      conditions.push(eq(schema.orders.status, status));
    }
    
    if (userId) {
      conditions.push(eq(schema.orders.userId, userId));
    }
    
    if (conditions.length > 0) {
      const whereCondition = conditions.reduce((acc, condition) => and(acc, condition));
      query = query.where(whereCondition);
      countQuery = countQuery.where(whereCondition);
    }
    
    // Apply sorting and pagination
    query = query.orderBy(desc(schema.orders.createdAt)).limit(limit).offset(offset);
    
    const [countResult] = await countQuery;
    const orders = await query;
    
    return {
      orders,
      count: countResult?.count || 0
    };
  }

  // OrderItem related methods
  async createOrderItem(orderItem: schema.InsertOrderItem): Promise<schema.OrderItem> {
    const [newOrderItem] = await db.insert(schema.orderItems).values(orderItem).returning();
    return newOrderItem;
  }

  async getOrderItemsByOrderId(orderId: number): Promise<schema.OrderItem[]> {
    return db
      .select()
      .from(schema.orderItems)
      .where(eq(schema.orderItems.orderId, orderId));
  }

  // CustomRequest related methods
  async createCustomRequest(customRequest: schema.InsertCustomRequest, userId?: number): Promise<schema.CustomRequest> {
    const [newCustomRequest] = await db
      .insert(schema.customRequests)
      .values({
        ...customRequest,
        userId: userId || null
      })
      .returning();
    
    return newCustomRequest;
  }

  async getCustomRequestById(id: number): Promise<schema.CustomRequest | undefined> {
    const [customRequest] = await db
      .select()
      .from(schema.customRequests)
      .where(eq(schema.customRequests.id, id));
    
    return customRequest;
  }

  async getCustomRequestsByUserId(userId: number): Promise<schema.CustomRequest[]> {
    return db
      .select()
      .from(schema.customRequests)
      .where(eq(schema.customRequests.userId, userId))
      .orderBy(desc(schema.customRequests.createdAt));
  }

  async updateCustomRequestStatus(id: number, status: string, adminNotes?: string): Promise<schema.CustomRequest> {
    const [updatedCustomRequest] = await db
      .update(schema.customRequests)
      .set({ 
        status, 
        adminNotes: adminNotes || undefined,
        updatedAt: new Date() 
      })
      .where(eq(schema.customRequests.id, id))
      .returning();
    
    if (!updatedCustomRequest) {
      throw new Error(`Custom request with id ${id} not found`);
    }
    
    return updatedCustomRequest;
  }

  async getCustomRequests(params: CustomRequestQueryParams = {}): Promise<{ requests: schema.CustomRequest[], count: number }> {
    const { page = 1, limit = 10, status, userId } = params;
    const offset = (page - 1) * limit;
    
    let query = db.select().from(schema.customRequests);
    let countQuery = db.select({ count: sql<number>`count(*)` }).from(schema.customRequests);
    
    // Apply filters
    const conditions = [];
    
    if (status) {
      conditions.push(eq(schema.customRequests.status, status));
    }
    
    if (userId) {
      conditions.push(eq(schema.customRequests.userId, userId));
    }
    
    if (conditions.length > 0) {
      const whereCondition = conditions.reduce((acc, condition) => and(acc, condition));
      query = query.where(whereCondition);
      countQuery = countQuery.where(whereCondition);
    }
    
    // Apply sorting and pagination
    query = query.orderBy(desc(schema.customRequests.createdAt)).limit(limit).offset(offset);
    
    const [countResult] = await countQuery;
    const requests = await query;
    
    return {
      requests,
      count: countResult?.count || 0
    };
  }

  // ProductImage related methods
  async createProductImage(productImage: schema.InsertProductImage): Promise<schema.ProductImage> {
    const [newProductImage] = await db.insert(schema.productImages).values(productImage).returning();
    return newProductImage;
  }

  async getProductImagesByProductId(productId: number): Promise<schema.ProductImage[]> {
    return db
      .select()
      .from(schema.productImages)
      .where(eq(schema.productImages.productId, productId))
      .orderBy(desc(schema.productImages.isPrimary));
  }

  async deleteProductImage(id: number): Promise<void> {
    await db.delete(schema.productImages).where(eq(schema.productImages.id, id));
  }
}

export const storage = new DatabaseStorage();
