import { pgTable, text, serial, integer, decimal, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { relations } from "drizzle-orm";
import { z } from "zod";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull(),
  fullName: text("full_name"),
  phone: text("phone"),
  isAdmin: boolean("is_admin").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

export const usersRelations = relations(users, ({ many }) => ({
  orders: many(orders),
  customRequests: many(customRequests)
}));

export const insertUserSchema = createInsertSchema(users, {
  username: (schema) => schema.min(3, "Username must be at least 3 characters"),
  password: (schema) => schema.min(6, "Password must be at least 6 characters"),
  email: (schema) => schema.email("Must provide a valid email")
}).omit({ isAdmin: true, createdAt: true });

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Product Categories table
export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  description: text("description"),
  imageUrl: text("image_url"),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

export const categoriesRelations = relations(categories, ({ many }) => ({
  products: many(products)
}));

export const insertCategorySchema = createInsertSchema(categories, {
  name: (schema) => schema.min(2, "Name must be at least 2 characters")
}).omit({ createdAt: true });

export type InsertCategory = z.infer<typeof insertCategorySchema>;
export type Category = typeof categories.$inferSelect;

// Materials table
export const materials = pgTable("materials", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

export const materialsRelations = relations(materials, ({ many }) => ({
  products: many(products)
}));

export const insertMaterialSchema = createInsertSchema(materials, {
  name: (schema) => schema.min(2, "Name must be at least 2 characters")
}).omit({ createdAt: true });

export type InsertMaterial = z.infer<typeof insertMaterialSchema>;
export type Material = typeof materials.$inferSelect;

// Work Types table
export const workTypes = pgTable("work_types", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

export const workTypesRelations = relations(workTypes, ({ many }) => ({
  products: many(products)
}));

export const insertWorkTypeSchema = createInsertSchema(workTypes, {
  name: (schema) => schema.min(2, "Name must be at least 2 characters")
}).omit({ createdAt: true });

export type InsertWorkType = z.infer<typeof insertWorkTypeSchema>;
export type WorkType = typeof workTypes.$inferSelect;

// Products table
export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  description: text("description").notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  discountPercent: decimal("discount_percent", { precision: 5, scale: 2 }).default("0"),
  imageUrl: text("image_url").notNull(),
  categoryId: integer("category_id").references(() => categories.id).notNull(),
  materialId: integer("material_id").references(() => materials.id).notNull(),
  workTypeId: integer("work_type_id").references(() => workTypes.id).notNull(),
  stock: integer("stock").default(0).notNull(),
  featured: boolean("featured").default(false).notNull(),
  isNew: boolean("is_new").default(false).notNull(),
  rating: decimal("rating", { precision: 3, scale: 1 }).default("0"),
  numReviews: integer("num_reviews").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

export const productsRelations = relations(products, ({ one, many }) => ({
  category: one(categories, {
    fields: [products.categoryId],
    references: [categories.id]
  }),
  material: one(materials, {
    fields: [products.materialId],
    references: [materials.id]
  }),
  workType: one(workTypes, {
    fields: [products.workTypeId],
    references: [workTypes.id]
  }),
  orderItems: many(orderItems),
  images: many(productImages)
}));

export const insertProductSchema = createInsertSchema(products, {
  name: (schema) => schema.min(3, "Name must be at least 3 characters"),
  description: (schema) => schema.min(10, "Description must be at least 10 characters"),
  price: (schema) => schema.refine(val => parseFloat(val) > 0, { message: "Price must be positive" })
}).omit({ createdAt: true, updatedAt: true, rating: true, numReviews: true });

export type InsertProduct = z.infer<typeof insertProductSchema>;
export type Product = typeof products.$inferSelect;

// Product Images table
export const productImages = pgTable("product_images", {
  id: serial("id").primaryKey(),
  productId: integer("product_id").references(() => products.id).notNull(),
  imageUrl: text("image_url").notNull(),
  isPrimary: boolean("is_primary").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

export const productImagesRelations = relations(productImages, ({ one }) => ({
  product: one(products, {
    fields: [productImages.productId],
    references: [products.id]
  })
}));

export const insertProductImageSchema = createInsertSchema(productImages).omit({ createdAt: true });

export type InsertProductImage = z.infer<typeof insertProductImageSchema>;
export type ProductImage = typeof productImages.$inferSelect;

// Orders table
export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  status: text("status").notNull().default("pending"),
  totalAmount: decimal("total_amount", { precision: 10, scale: 2 }).notNull(),
  shippingAddress: text("shipping_address").notNull(),
  shippingCity: text("shipping_city").notNull(),
  shippingState: text("shipping_state").notNull(),
  shippingPostalCode: text("shipping_postal_code").notNull(),
  shippingCountry: text("shipping_country").notNull(),
  paymentMethod: text("payment_method").notNull(),
  paymentId: text("payment_id"),
  isPaid: boolean("is_paid").default(false).notNull(),
  paidAt: timestamp("paid_at"),
  isDelivered: boolean("is_delivered").default(false).notNull(),
  deliveredAt: timestamp("delivered_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

export const ordersRelations = relations(orders, ({ one, many }) => ({
  user: one(users, {
    fields: [orders.userId],
    references: [users.id]
  }),
  orderItems: many(orderItems)
}));

export const insertOrderSchema = createInsertSchema(orders, {
  totalAmount: (schema) => schema.refine(val => parseFloat(val) > 0, { message: "Total amount must be positive" }),
  shippingAddress: (schema) => schema.min(5, "Shipping address is required"),
  shippingCity: (schema) => schema.min(2, "Shipping city is required"),
  shippingState: (schema) => schema.min(2, "Shipping state is required"),
  shippingPostalCode: (schema) => schema.min(2, "Shipping postal code is required"),
  shippingCountry: (schema) => schema.min(2, "Shipping country is required")
}).omit({ 
  createdAt: true, updatedAt: true, isPaid: true, 
  paidAt: true, isDelivered: true, deliveredAt: true 
});

export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type Order = typeof orders.$inferSelect;

// Order Items table
export const orderItems = pgTable("order_items", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").references(() => orders.id).notNull(),
  productId: integer("product_id").references(() => products.id).notNull(),
  quantity: integer("quantity").notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

export const orderItemsRelations = relations(orderItems, ({ one }) => ({
  order: one(orders, {
    fields: [orderItems.orderId],
    references: [orders.id]
  }),
  product: one(products, {
    fields: [orderItems.productId],
    references: [products.id]
  })
}));

export const insertOrderItemSchema = createInsertSchema(orderItems, {
  quantity: (schema) => schema.refine(val => parseInt(val.toString()) > 0, { message: "Quantity must be positive" }),
  price: (schema) => schema.refine(val => parseFloat(val.toString()) > 0, { message: "Price must be positive" })
});

// Helper type that extracts only the fields we want
export type InsertOrderItemType = {
  orderId: number;
  productId: number;
  quantity: number;
  price: number | string;
};

export type InsertOrderItem = z.infer<typeof insertOrderItemSchema>;
export type OrderItem = typeof orderItems.$inferSelect;

// Custom Requests table
export const customRequests = pgTable("custom_requests", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  fullName: text("full_name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  productType: text("product_type").notNull(),
  materials: text("materials").notNull(),
  workTypes: text("work_types").notNull(),
  budgetRange: text("budget_range").notNull(),
  requirements: text("requirements"),
  status: text("status").default("pending").notNull(),
  referenceImages: text("reference_images"),
  adminNotes: text("admin_notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

export const customRequestsRelations = relations(customRequests, ({ one }) => ({
  user: one(users, {
    fields: [customRequests.userId],
    references: [users.id]
  })
}));

export const insertCustomRequestSchema = createInsertSchema(customRequests, {
  fullName: (schema) => schema.min(3, "Full name must be at least 3 characters"),
  email: (schema) => schema.email("Must provide a valid email"),
  phone: (schema) => schema.min(10, "Phone number must be at least 10 characters")
}).omit({ 
  status: true, adminNotes: true, createdAt: true, updatedAt: true, userId: true 
});

export type InsertCustomRequest = z.infer<typeof insertCustomRequestSchema>;
export type CustomRequest = typeof customRequests.$inferSelect;
